"""
risk_manager.py — per-trade risk checks against account limits.

All dollar amounts are in USD.  Options premium is quoted per share;
one standard contract = 100 shares, so:
    position_cost = premium_per_contract * num_contracts * 100
"""

from __future__ import annotations

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config


# ── helpers ───────────────────────────────────────────────────────────────────

def _open_position_cost() -> float:
    """
    Sum of total_cost for all currently open trades (no exit logged yet).
    Imported here to avoid circular imports at module level.
    """
    try:
        from trade_logger import get_open_position_cost
        return get_open_position_cost()
    except Exception:
        return 0.0


# ── public API ────────────────────────────────────────────────────────────────

def check_trade(premium_per_contract: float, num_contracts: int) -> dict:
    """
    Validate a proposed trade against account risk rules.

    Parameters
    ----------
    premium_per_contract : float
        Mid-price of the option (e.g. $2.50).
    num_contracts : int
        Number of contracts to buy (each = 100 shares).

    Returns
    -------
    dict with keys:
        approved       : bool
        reason         : str   (human-readable verdict)
        position_cost  : float (total $ committed if approved)
    """
    position_cost = premium_per_contract * num_contracts * 100
    open_cost     = _open_position_cost()

    if position_cost > config.MAX_RISK_PER_TRADE:
        return {
            "approved":      False,
            "reason":        (
                f"Trade cost ${position_cost:.2f} exceeds MAX_RISK_PER_TRADE "
                f"(${config.MAX_RISK_PER_TRADE})"
            ),
            "position_cost": position_cost,
        }

    if open_cost + position_cost > config.MAX_POSITION_SIZE:
        return {
            "approved":      False,
            "reason":        (
                f"Total open exposure ${open_cost + position_cost:.2f} would exceed "
                f"MAX_POSITION_SIZE (${config.MAX_POSITION_SIZE}). "
                f"Currently open: ${open_cost:.2f}"
            ),
            "position_cost": position_cost,
        }

    return {
        "approved":      True,
        "reason":        (
            f"APPROVED - {num_contracts} contract(s) @ ${premium_per_contract:.2f} "
            f"= ${position_cost:.2f}"
        ),
        "position_cost": position_cost,
    }


def suggest_contracts(premium_per_contract: float) -> int:
    """
    Return the maximum number of contracts buyable within MAX_RISK_PER_TRADE.
    Always returns at least 0 (if even 1 contract exceeds the limit).
    """
    if premium_per_contract <= 0:
        return 0
    cost_per_contract = premium_per_contract * 100
    return int(config.MAX_RISK_PER_TRADE // cost_per_contract)


def calculate_stops(entry_premium: float) -> dict:
    """
    Given entry premium (per share), return stop-loss and profit-target prices.

    Returns
    -------
    dict with keys:
        entry_premium  : float
        stop_loss      : float   (entry * (1 - STOP_LOSS_PCT))
        profit_target  : float   (entry * (1 + PROFIT_TARGET_PCT))
    """
    return {
        "entry_premium":  round(entry_premium, 2),
        "stop_loss":      round(entry_premium * (1 - config.STOP_LOSS_PCT), 2),
        "profit_target":  round(entry_premium * (1 + config.PROFIT_TARGET_PCT), 2),
    }


def risk_summary() -> dict:
    """Return a snapshot of current risk usage vs. limits."""
    open_cost = _open_position_cost()
    remaining = max(config.MAX_POSITION_SIZE - open_cost, 0.0)
    return {
        "account_size":      config.ACCOUNT_SIZE,
        "buying_power":      config.BUYING_POWER,
        "open_position_cost": round(open_cost, 2),
        "max_position_size":  config.MAX_POSITION_SIZE,
        "risk_remaining":     round(remaining, 2),
        "max_risk_per_trade": config.MAX_RISK_PER_TRADE,
    }
