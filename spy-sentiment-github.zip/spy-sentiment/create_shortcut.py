"""
create_shortcut.py — Creates a Desktop shortcut (.lnk) to Cerebro Trading.exe
Uses pywin32 (win32com.client).
"""

import os
import sys
from pathlib import Path

ROOT    = Path(__file__).resolve().parent
EXE     = ROOT / "dist" / "Cerebro Trading.exe"
ICON    = ROOT / "assets" / "icon.ico"
def _get_desktop() -> Path:
    """Use Windows shell to get the real Desktop path (handles OneDrive redirect)."""
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders")
        val, _ = winreg.QueryValueEx(key, "Desktop")
        winreg.CloseKey(key)
        return Path(val)
    except Exception:
        return Path(os.path.expanduser("~")) / "Desktop"

DESKTOP = _get_desktop()


def create_shortcut() -> None:
    try:
        import win32com.client  # type: ignore
    except ImportError:
        print("pywin32 not installed. Run: pip install pywin32")
        sys.exit(1)

    if not EXE.exists():
        print(f"EXE not found at {EXE}. Run build_app.bat first.")
        sys.exit(1)

    lnk_path = str(DESKTOP / "Cerebro Trading System.lnk")
    shell    = win32com.client.Dispatch("WScript.Shell")
    shortcut = shell.CreateShortCut(lnk_path)
    shortcut.Targetpath       = str(EXE)
    shortcut.WorkingDirectory = str(ROOT)
    shortcut.IconLocation     = f"{ICON},0"
    shortcut.Description      = "Cerebro SPY Options Sentiment Trading System"
    shortcut.save()
    print(f"Shortcut created: {lnk_path}")


if __name__ == "__main__":
    create_shortcut()
