"""
trade_logger.py — SQLite-backed log of signals, entries, and exits.

Schema (TRADE_DB):
  signals
    id, timestamp, sentiment_score, signal_direction, sentiment_sources TEXT

  trades
    id, trade_id TEXT, contract TEXT, strike REAL, expiry TEXT,
    premium REAL, contracts INT, total_cost REAL, pdt_count INT,
    entry_time TEXT, exit_premium REAL, pnl REAL, exit_reason TEXT,
    exit_time TEXT, status TEXT ('OPEN'|'CLOSED')
"""

from __future__ import annotations

import sqlite3
import logging
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Generator

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

log = logging.getLogger(__name__)


# ── DB helpers ────────────────────────────────────────────────────────────────

@contextmanager
def _conn() -> Generator[sqlite3.Connection, None, None]:
    c = sqlite3.connect(config.TRADE_DB)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def _init() -> None:
    with _conn() as c:
        c.executescript("""
            CREATE TABLE IF NOT EXISTS signals (
                id                 INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp          TEXT NOT NULL,
                sentiment_score    REAL,
                signal_direction   TEXT,
                sentiment_sources  TEXT
            );

            CREATE TABLE IF NOT EXISTS trades (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                trade_id      TEXT NOT NULL UNIQUE,
                contract      TEXT,
                strike        REAL,
                expiry        TEXT,
                premium       REAL,
                contracts     INTEGER,
                total_cost    REAL,
                pdt_count     INTEGER,
                entry_time    TEXT,
                exit_premium  REAL,
                pnl           REAL,
                exit_reason   TEXT,
                exit_time     TEXT,
                status        TEXT DEFAULT 'OPEN'
            );

            CREATE INDEX IF NOT EXISTS idx_sig_ts   ON signals(timestamp);
            CREATE INDEX IF NOT EXISTS idx_trade_id ON trades(trade_id);
            CREATE INDEX IF NOT EXISTS idx_trade_st ON trades(status);
        """)


# ── public API ────────────────────────────────────────────────────────────────

def log_signal(timestamp: datetime, sentiment_score: float,
               signal_direction: str, sentiment_sources: list[str] | str) -> int:
    """Persist a pipeline signal. Returns the inserted row id."""
    _init()
    if isinstance(sentiment_sources, list):
        sentiment_sources = ", ".join(sentiment_sources)
    with _conn() as c:
        cur = c.execute(
            """INSERT INTO signals (timestamp, sentiment_score, signal_direction, sentiment_sources)
               VALUES (?,?,?,?)""",
            (timestamp.isoformat(), sentiment_score, signal_direction, sentiment_sources),
        )
    return cur.lastrowid


def log_entry(trade_id: str, contract: str, strike: float, expiry: str,
              premium: float, contracts: int, total_cost: float,
              pdt_count: int) -> int:
    """Record a new trade entry. Returns the inserted row id."""
    _init()
    entry_time = datetime.now(timezone.utc).isoformat()
    with _conn() as c:
        cur = c.execute(
            """INSERT OR REPLACE INTO trades
               (trade_id, contract, strike, expiry, premium, contracts,
                total_cost, pdt_count, entry_time, status)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (trade_id, contract, strike, expiry, premium, contracts,
             total_cost, pdt_count, entry_time, "OPEN"),
        )
    log.info("Trade entry logged: %s  %s  $%.2f x %d = $%.2f",
             trade_id, contract, premium, contracts, total_cost)
    return cur.lastrowid


def log_exit(trade_id: str, exit_premium: float,
             pnl: float, exit_reason: str) -> None:
    """Mark a trade as closed and record P&L."""
    _init()
    exit_time = datetime.now(timezone.utc).isoformat()
    with _conn() as c:
        c.execute(
            """UPDATE trades SET exit_premium=?, pnl=?, exit_reason=?,
               exit_time=?, status='CLOSED' WHERE trade_id=?""",
            (exit_premium, pnl, exit_reason, exit_time, trade_id),
        )
    log.info("Trade exit logged: %s  pnl=$%.2f  reason=%s",
             trade_id, pnl, exit_reason)


def get_open_position_cost() -> float:
    """Return the sum of total_cost for all OPEN trades."""
    _init()
    with _conn() as c:
        row = c.execute(
            "SELECT COALESCE(SUM(total_cost), 0) as total FROM trades WHERE status='OPEN'"
        ).fetchone()
    return float(row["total"])


def get_open_trades() -> list[dict]:
    """Return all currently open trade records."""
    _init()
    with _conn() as c:
        rows = c.execute(
            "SELECT * FROM trades WHERE status='OPEN' ORDER BY entry_time"
        ).fetchall()
    return [dict(r) for r in rows]


def get_total_pnl() -> float:
    """Return cumulative realised P&L across all closed trades."""
    _init()
    with _conn() as c:
        row = c.execute(
            "SELECT COALESCE(SUM(pnl), 0) as total FROM trades WHERE status='CLOSED'"
        ).fetchone()
    return float(row["total"])


def daily_summary() -> None:
    """Print account status, open positions, PDT count, and total P&L."""
    _init()
    from pdt_tracker  import get_pdt_status
    from risk_manager import risk_summary

    pdt  = get_pdt_status()
    risk = risk_summary()
    open_trades = get_open_trades()
    total_pnl   = get_total_pnl()

    print()
    print("=" * 50)
    print("  DAILY SUMMARY")
    print("=" * 50)
    print(f"  Account Size  : ${risk['account_size']:,.2f}")
    print(f"  Open Exposure : ${risk['open_position_cost']:,.2f} / "
          f"${risk['max_position_size']:,.2f}")
    print(f"  Risk Remaining: ${risk['risk_remaining']:,.2f}")
    print(f"  Realised PnL  : ${total_pnl:+,.2f}")
    print(f"  PDT Used      : {pdt['day_trades_used']} / {config.PDT_MAX_DAY_TRADES}  "
          f"(resets {pdt['resets_on']})")
    print(f"  Open Positions: {len(open_trades)}")
    for t in open_trades:
        print(f"    [{t['trade_id'][:8]}] {t['contract']}  "
              f"entry=${t['premium']:.2f}  cost=${t['total_cost']:.2f}")
    print("=" * 50)
    print()
