"""
cerebro_engine.py — Cerebro background engine.

Runs 24/7 silently. Never imports anything from jarvis/.
Never trades. Compiles intelligence reports.

Schedule:
  Every 15 min (market hours):  collect + analyze + compile_report()
  Every 1 hour:                  update_economic_calendar(), check_market_regime()
  Every Sunday midnight:         retrain_models(), compile_weekly_report()
  On startup:                    load_all_models(), verify_database_health()
"""

from __future__ import annotations

import logging
import os
import sqlite3
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)

# Cerebro writes ONLY to cerebro.log — never to console
_log_path = str(LOG_DIR / "cerebro.log")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[logging.FileHandler(_log_path, encoding="utf-8")],
)
log = logging.getLogger("cerebro.engine")


# ── Helpers ────────────────────────────────────────────────────────────────────

def _is_market_hours() -> bool:
    try:
        import pytz
        from datetime import time as dtime
        et  = pytz.timezone("America/New_York")
        now = datetime.now(et)
        return now.weekday() < 5 and dtime(9, 30) <= now.time() < dtime(16, 0)
    except Exception:
        return True   # default open


def _is_sunday_midnight() -> bool:
    now = datetime.now()
    return now.weekday() == 6 and now.hour == 0 and now.minute < 16


# ── Startup tasks ──────────────────────────────────────────────────────────────

def load_all_models() -> None:
    log.info("Loading ensemble models...")
    try:
        from cerebro.historical.cerebro_trainer_v2 import load_ensemble
        models = load_ensemble()
        log.info("Loaded %d model(s): %s", len(models), list(models))
    except Exception as e:
        log.warning("No trained models found (%s) — run --train to create them", e)


def verify_database_health() -> None:
    log.info("Verifying database health...")
    import config
    for label, path in [("sentiment", config.DB_PATH),
                        ("pdt",       config.PDT_DB),
                        ("trades",    config.TRADE_DB)]:
        try:
            with sqlite3.connect(path) as c:
                c.execute("SELECT 1")
            log.info("  %s DB OK → %s", label, path)
        except Exception as e:
            log.error("  %s DB FAILED: %s", label, e)

    # Init tables if needed
    try:
        from storage.db   import init_db
        from trade_logger import _init as tl_init
        from pdt_tracker  import _init as pt_init
        init_db(); tl_init(); pt_init()
    except Exception as e:
        log.warning("DB init partial: %s", e)


# ── 15-minute tasks (market hours) ────────────────────────────────────────────

def collect_all_data() -> None:
    """Trigger news + price fetch (fetchers.py handles caching internally)."""
    log.debug("Collecting latest data...")
    try:
        from scraper.fetchers import fetch_all
        articles = fetch_all()
        log.info("Collected %d articles", len(articles))
    except Exception as e:
        log.warning("Data collection error: %s", e)


def run_sentiment_analysis() -> None:
    try:
        from scraper.processor import score_articles, filter_relevant, compute_composite
        from scraper.fetchers  import fetch_all
        arts  = filter_relevant(fetch_all())
        scored = score_articles(arts)
        result = compute_composite(scored)
        log.info("Sentiment: %s (%.3f) from %d articles",
                 result.get("signal"), result.get("composite_score", 0), len(scored))
    except Exception as e:
        log.warning("Sentiment analysis error: %s", e)


def run_technical_analysis() -> None:
    try:
        from cerebro.report_compiler import _get_spy_daily, calculate_technicals
        df   = _get_spy_daily()
        tech = calculate_technicals(df)
        log.info("Technicals: %s score=%.2f RSI=%.1f",
                 tech.get("direction"), tech.get("score", 0), tech.get("rsi", 0))
    except Exception as e:
        log.warning("Technical analysis error: %s", e)


def run_pattern_matching() -> None:
    try:
        from cerebro.historical.pattern_library import build_all_profiles
        # Only rebuild if DB is populated
        from cerebro.historical.cerebro_trainer_v2 import _conn
        with _conn() as c:
            n = c.execute("SELECT COUNT(*) FROM spy_prices").fetchone()[0]
        if n > 0:
            build_all_profiles()
            log.info("Pattern library refreshed (%d price rows)", n)
    except Exception as e:
        log.debug("Pattern matching skipped: %s", e)


def run_options_analysis() -> None:
    try:
        from cerebro.report_compiler import get_options_data
        opts = get_options_data()
        log.info("Options: IV rank=%d PC=%.2f unusual=%s",
                 opts.get("iv_rank", 0), opts.get("put_call_ratio", 1),
                 opts.get("unusual_flow") or "none")
    except Exception as e:
        log.warning("Options analysis error: %s", e)


def compile_report() -> None:
    try:
        from cerebro.report_compiler import compile_report as _compile
        report = _compile()
        log.info("Report compiled: %s sentiment=%s technicals=%s ML=%.0f%%",
                 report.get("market_status"),
                 report["sentiment"].get("direction"),
                 report["technicals"].get("direction"),
                 report["ml_prediction"].get("probability_bullish", 0.5) * 100)
    except Exception as e:
        log.error("compile_report failed: %s", e)


# ── Hourly tasks ───────────────────────────────────────────────────────────────

def update_economic_calendar() -> None:
    try:
        from cerebro.historical.economic_calendar import get_upcoming_events
        events = get_upcoming_events(days_ahead=30)
        log.info("Economic calendar: %d events next 30 days", len(events))
    except Exception as e:
        log.debug("Calendar update skipped: %s", e)


def check_market_regime() -> None:
    try:
        from cerebro.historical.era_classifier import get_current_era, vix_regime
        from cerebro.report_compiler import get_vix_data
        vix_d = get_vix_data()
        era   = get_current_era()
        reg   = vix_regime(vix_d.get("vix", 20.0))
        era_k = era.get("era_key", "unknown") if era else "unknown"
        log.info("Market regime: era=%s vix_regime=%s vix=%.1f",
                 era_k, reg, vix_d.get("vix", 0))
    except Exception as e:
        log.debug("Regime check skipped: %s", e)


def update_pattern_library() -> None:
    try:
        from cerebro.historical.pattern_library import build_all_profiles
        build_all_profiles()
        log.info("Pattern library updated")
    except Exception as e:
        log.debug("Pattern library update skipped: %s", e)


# ── Weekly tasks (Sunday midnight) ────────────────────────────────────────────

def retrain_models() -> None:
    log.info("Weekly model retrain starting...")
    try:
        from cerebro.historical.cerebro_trainer_v2 import build_mega_dataset, train_ensemble
        df = build_mega_dataset()
        if len(df) >= 100:
            metrics = train_ensemble(df)
            log.info("Retrain complete: %s", metrics)
        else:
            log.warning("Not enough data to retrain (rows=%d)", len(df))
    except Exception as e:
        log.error("Retrain failed: %s", e)


def generate_weekly_report() -> None:
    try:
        from cerebro.report_compiler import compile_weekly_report
        r = compile_weekly_report()
        log.info("Weekly report generated: best_bot=%s accuracy=%.1f%%",
                 r.get("best_bot_this_week"), r.get("cerebro_accuracy", 0) * 100)
    except Exception as e:
        log.error("Weekly report failed: %s", e)


def evaluate_jarvis_performance() -> None:
    """Score each bot's week and log findings."""
    try:
        import sqlite3, sys
        sys.path.insert(0, str(ROOT))
        import config
        with sqlite3.connect(config.TRADE_DB) as c:
            c.row_factory = sqlite3.Row
            for bot in ("buffett", "belfort", "standard"):
                r = c.execute(
                    """SELECT COUNT(*) n,
                              SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END) wins,
                              COUNT(CASE WHEN status='CLOSED' THEN 1 END) closed
                       FROM bot_trades
                       WHERE bot=? AND entry_time >= date('now','-7 days')""",
                    (bot,),
                ).fetchone()
                wr = (r["wins"] or 0) / max(r["closed"] or 0, 1)
                log.info("  %s: trades=%d win_rate=%.0f%%", bot, r["n"] or 0, wr * 100)
    except Exception as e:
        log.debug("Jarvis eval skipped: %s", e)


def promote_best_to_ultron() -> None:
    """If a bot hits 65%+ win rate this week, log the recommendation."""
    try:
        import sqlite3, sys
        sys.path.insert(0, str(ROOT))
        import config
        best_bot, best_wr = None, 0.0
        with sqlite3.connect(config.TRADE_DB) as c:
            c.row_factory = sqlite3.Row
            for bot in ("buffett", "belfort", "standard"):
                r = c.execute(
                    """SELECT SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END) wins,
                              COUNT(CASE WHEN status='CLOSED' THEN 1 END) closed
                       FROM bot_trades
                       WHERE bot=? AND entry_time >= date('now','-7 days')""",
                    (bot,),
                ).fetchone()
                wr = (r["wins"] or 0) / max(r["closed"] or 0, 1)
                if wr > best_wr:
                    best_wr, best_bot = wr, bot
        if best_bot and best_wr >= 0.65:
            log.info("ULTRON PROMOTION: %s qualifies with %.0f%% win rate",
                     best_bot, best_wr * 100)
        else:
            log.info("No Ultron promotion this week (best: %s %.0f%%)",
                     best_bot, (best_wr or 0) * 100)
    except Exception as e:
        log.debug("Ultron promotion skipped: %s", e)


# ── Main loop ──────────────────────────────────────────────────────────────────

def main() -> None:
    log.info("=" * 55)
    log.info("  CEREBRO ENGINE STARTING")
    log.info("=" * 55)

    # Startup
    verify_database_health()
    load_all_models()

    # Compile initial report regardless of market hours
    compile_report()

    last_15min   = 0.0
    last_hourly  = 0.0
    last_weekly  = 0.0
    INTERVAL_15M = 15 * 60
    INTERVAL_1H  = 60 * 60

    log.info("Cerebro engine running. Logs → %s", _log_path)

    while True:
        now = time.time()

        # ── 15-minute cycle (market hours) ────────────────────────────────
        if now - last_15min >= INTERVAL_15M:
            last_15min = now
            if _is_market_hours():
                log.info("--- 15-min cycle ---")
                collect_all_data()
                run_sentiment_analysis()
                run_technical_analysis()
                run_pattern_matching()
                run_options_analysis()
                compile_report()
            else:
                log.debug("Market closed — skipping 15-min cycle")
                compile_report()   # still update (shows market_status=closed)

        # ── Hourly cycle ──────────────────────────────────────────────────
        if now - last_hourly >= INTERVAL_1H:
            last_hourly = now
            log.info("--- hourly cycle ---")
            update_economic_calendar()
            check_market_regime()
            update_pattern_library()

        # ── Weekly cycle ──────────────────────────────────────────────────
        if _is_sunday_midnight() and now - last_weekly >= INTERVAL_1H:
            last_weekly = now
            log.info("--- weekly cycle (Sunday) ---")
            retrain_models()
            generate_weekly_report()
            evaluate_jarvis_performance()
            promote_best_to_ultron()

        time.sleep(30)


if __name__ == "__main__":
    main()
