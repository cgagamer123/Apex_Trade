"""
cerebro_trainer_v2.py — Trains ensemble ML model on full historical dataset.

build_mega_dataset()   → combines all sources into a feature matrix
train_ensemble()       → XGBoost + RandomForest + LightGBM ensemble
                         saves models to models/ directory
"""

from __future__ import annotations

import json
import os
import pickle
import sqlite3
from contextlib import contextmanager
from datetime import date, timedelta
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

ROOT      = Path(__file__).resolve().parent.parent.parent
HIST_DB   = str(ROOT / "database" / "market_history.db")
MODEL_DIR = ROOT / "models"
MODEL_DIR.mkdir(exist_ok=True)


@contextmanager
def _conn():
    c = sqlite3.connect(HIST_DB)
    c.row_factory = sqlite3.Row
    try:
        yield c
    finally:
        c.close()


# ── Feature engineering ───────────────────────────────────────────────────────

def _load_spy_prices() -> pd.DataFrame:
    with _conn() as c:
        df = pd.read_sql("SELECT date, close FROM spy_prices ORDER BY date", c,
                         parse_dates=["date"])
    df = df.set_index("date").sort_index()
    df["ret_1d"]  = df["close"].pct_change(1)
    df["ret_5d"]  = df["close"].pct_change(5)
    df["ret_20d"] = df["close"].pct_change(20)
    # RSI-14
    delta = df["close"].diff()
    gain  = delta.clip(lower=0).rolling(14).mean()
    loss  = (-delta.clip(upper=0)).rolling(14).mean()
    df["rsi_14"] = 100 - (100 / (1 + gain / loss.replace(0, 1e-9)))
    # MA flags
    df["above_50ma"]  = (df["close"] > df["close"].rolling(50).mean()).astype(int)
    df["above_200ma"] = (df["close"] > df["close"].rolling(200).mean()).astype(int)
    return df


def _load_vix() -> pd.DataFrame:
    with _conn() as c:
        df = pd.read_sql("SELECT date, close as vix FROM vix_history ORDER BY date",
                         c, parse_dates=["date"])
    df = df.set_index("date")
    df["vix_pct_1yr"] = df["vix"].rank(pct=True)
    df["vix_regime"]  = pd.cut(df["vix"],
                                bins=[0, 15, 25, 35, 999],
                                labels=["low","medium","high","crisis"])
    return df


def _load_fred_series() -> pd.DataFrame:
    with _conn() as c:
        rows = c.execute(
            "SELECT date, series, value FROM economic_indicators ORDER BY date"
        ).fetchall()
    if not rows:
        return pd.DataFrame()
    data: dict[str, dict] = {}
    for r in rows:
        data.setdefault(r["date"], {})[r["series"]] = r["value"]
    df = pd.DataFrame.from_dict(data, orient="index")
    df.index = pd.to_datetime(df.index)
    df = df.sort_index()
    return df


def _load_news_sentiment() -> pd.DataFrame:
    """Aggregate daily average FinBERT sentiment from historical_news."""
    with _conn() as c:
        rows = c.execute("""
            SELECT pub_date, AVG(sentiment) as avg_sent, COUNT(*) as n_articles
            FROM historical_news
            WHERE sentiment IS NOT NULL
            GROUP BY pub_date
            ORDER BY pub_date
        """).fetchall()
    if not rows:
        return pd.DataFrame(columns=["avg_sent","n_articles"])
    df = pd.DataFrame(rows, columns=["date","avg_sent","n_articles"])
    df["date"] = pd.to_datetime(df["date"])
    return df.set_index("date")


def _load_recession() -> pd.DataFrame:
    with _conn() as c:
        rows = c.execute("SELECT date, in_recession FROM recession_dates").fetchall()
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows, columns=["date","in_recession"])
    df["date"] = pd.to_datetime(df["date"])
    return df.set_index("date")


def build_mega_dataset() -> pd.DataFrame:
    """
    Combine all historical sources into a single feature matrix.
    Returns a DataFrame with one row per trading day (where data available).
    """
    print("  Loading SPY prices...")
    spy  = _load_spy_prices()
    print(f"    {len(spy)} price records")

    print("  Loading VIX...")
    vix  = _load_vix()

    print("  Loading FRED indicators...")
    fred = _load_fred_series()

    print("  Loading news sentiment...")
    news = _load_news_sentiment()

    print("  Loading recession flags...")
    rec  = _load_recession()

    # Merge on date index
    df = spy.copy()
    if not vix.empty:
        df = df.join(vix[["vix","vix_pct_1yr","vix_regime"]], how="left")
    if not fred.empty:
        # Key columns only
        cols = [c for c in ["FEDFUNDS","T10Y2Y","CPIAUCSL","UNRATE"] if c in fred.columns]
        df = df.join(fred[cols], how="left")
    if not news.empty:
        df = df.join(news[["avg_sent","n_articles"]], how="left")
    if not rec.empty:
        df = df.join(rec["in_recession"], how="left")

    # Calendar features
    df["day_of_week"] = df.index.dayofweek
    df["month"]       = df.index.month
    df["quarter"]     = df.index.quarter

    # Era label
    from cerebro.historical.era_classifier import classify_era
    df["era"] = df.index.strftime("%Y-%m-%d").map(classify_era)

    # Target: direction next day (1=up>0.3%, 0=flat, -1=down>0.3%)
    spy_fwd = spy["close"].shift(-1)
    df["target_dir"] = np.where(spy_fwd / spy["close"] - 1 > 0.003,  1,
                       np.where(spy_fwd / spy["close"] - 1 < -0.003, -1, 0))
    df["target_move"] = (spy_fwd / spy["close"] - 1) * 100  # actual % move

    df = df.dropna(subset=["close", "target_dir"])
    print(f"  Mega dataset: {len(df)} rows, {len(df.columns)} features")
    return df


# ── Model training ─────────────────────────────────────────────────────────────

def train_ensemble(df: pd.DataFrame | None = None,
                   test_start: str = "2022-01-01") -> dict:
    """
    Train XGBoost + RandomForest + LightGBM on the mega dataset.
    Saves models to models/ directory.
    Returns evaluation metrics.
    """
    if df is None:
        df = build_mega_dataset()

    feature_cols = [c for c in df.columns
                    if c not in ("target_dir","target_move","era","vix_regime")]
    # Encode era and vix_regime as integers
    for col in ["era","vix_regime"]:
        if col in df.columns:
            df[col + "_enc"] = pd.Categorical(df[col]).codes
            feature_cols.append(col + "_enc")

    X = df[feature_cols].fillna(0).astype(float)
    y = (df["target_dir"] + 1).astype(int)   # 0/1/2 for -1/0/+1

    split = X.index.searchsorted(pd.Timestamp(test_start))
    X_train, X_test = X.iloc[:split], X.iloc[split:]
    y_train, y_test = y.iloc[:split], y.iloc[split:]

    if len(X_train) < 100:
        print("  Not enough training data yet. Run Phase 1 downloads first.")
        return {}

    metrics: dict[str, Any] = {}
    models: dict[str, Any] = {}

    # ── XGBoost ─────────────────────────────────────────────────────────────
    try:
        from xgboost import XGBClassifier  # type: ignore
        xgb = XGBClassifier(n_estimators=300, max_depth=5, learning_rate=0.05,
                             use_label_encoder=False, eval_metric="mlogloss",
                             verbosity=0, random_state=42)
        xgb.fit(X_train, y_train)
        acc = (xgb.predict(X_test) == y_test).mean()
        metrics["xgboost_acc"] = round(float(acc), 4)
        models["xgboost"] = xgb
        print(f"  XGBoost test accuracy: {acc:.1%}")
    except ImportError:
        print("  xgboost not installed. Run: pip install xgboost")

    # ── RandomForest ─────────────────────────────────────────────────────────
    try:
        from sklearn.ensemble import RandomForestClassifier  # type: ignore
        rf = RandomForestClassifier(n_estimators=200, max_depth=8,
                                    n_jobs=-1, random_state=42)
        rf.fit(X_train, y_train)
        acc = (rf.predict(X_test) == y_test).mean()
        metrics["rf_acc"] = round(float(acc), 4)
        models["rf"] = rf
        print(f"  RandomForest test accuracy: {acc:.1%}")
    except ImportError:
        print("  scikit-learn not installed. Run: pip install scikit-learn")

    # ── LightGBM ─────────────────────────────────────────────────────────────
    try:
        import lightgbm as lgb  # type: ignore
        lgb_model = lgb.LGBMClassifier(n_estimators=300, learning_rate=0.05,
                                        max_depth=6, random_state=42, verbose=-1)
        lgb_model.fit(X_train, y_train)
        acc = (lgb_model.predict(X_test) == y_test).mean()
        metrics["lgbm_acc"] = round(float(acc), 4)
        models["lgbm"] = lgb_model
        print(f"  LightGBM test accuracy: {acc:.1%}")
    except ImportError:
        print("  lightgbm not installed. Run: pip install lightgbm")

    # ── Save ─────────────────────────────────────────────────────────────────
    for name, model in models.items():
        path = MODEL_DIR / f"{name}_model.pkl"
        with open(path, "wb") as f:
            pickle.dump(model, f)
        print(f"  Saved {path.name}")

    # Save feature list
    with open(MODEL_DIR / "feature_cols.json", "w") as f:
        json.dump(feature_cols, f)

    # Save metrics
    with open(MODEL_DIR / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    ensemble_acc = round(sum(metrics.values()) / len(metrics), 4) if metrics else 0
    metrics["ensemble_acc"] = ensemble_acc
    print(f"\n  Ensemble avg accuracy: {ensemble_acc:.1%}")
    print(f"  Training complete — {len(X_train)} train / {len(X_test)} test rows")
    return metrics


def load_ensemble() -> dict:
    """Load saved models. Returns dict {name: model}."""
    models = {}
    for name in ("xgboost", "rf", "lgbm"):
        path = MODEL_DIR / f"{name}_model.pkl"
        if path.exists():
            with open(path, "rb") as f:
                models[name] = pickle.load(f)
    return models


def predict_ensemble(features: dict) -> dict:
    """
    Run a single prediction through the ensemble.

    features: dict of feature_name → float (missing values filled with 0)
    Returns: {signal: BULLISH/BEARISH/NEUTRAL, confidence: float, votes: dict}
    """
    models = load_ensemble()
    if not models:
        return {"signal": "NEUTRAL", "confidence": 0.0, "votes": {}}

    feat_path = MODEL_DIR / "feature_cols.json"
    if not feat_path.exists():
        return {"signal": "NEUTRAL", "confidence": 0.0, "votes": {}}
    with open(feat_path) as f:
        cols = json.load(f)

    x = pd.DataFrame([[features.get(c, 0.0) for c in cols]], columns=cols)
    votes: dict[str, int] = {}
    probs: list[list[float]] = []

    for name, model in models.items():
        pred = int(model.predict(x)[0])
        votes[name] = pred
        try:
            prob = model.predict_proba(x)[0].tolist()
            probs.append(prob)
        except Exception:
            pass

    # Majority vote (0=bear, 1=neutral, 2=bull)
    from collections import Counter
    majority = Counter(votes.values()).most_common(1)[0][0]
    signal = {0: "BEARISH", 1: "NEUTRAL", 2: "BULLISH"}.get(majority, "NEUTRAL")

    confidence = 0.0
    if probs:
        avg_prob = [sum(p[i] for p in probs) / len(probs) for i in range(3)]
        confidence = round(max(avg_prob) * 100, 1)

    return {"signal": signal, "confidence": confidence, "votes": votes}
