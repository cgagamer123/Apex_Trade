"""
deep_history_collector.py — Downloads all free historical market data.

Phase 1  (<30 min, run first):
  download_shiller_data()      1871+ monthly S&P, earnings, CPI
  download_stooq_history()     1896+ DJIA, 1927+ SPX daily
  download_spy_full()          1927+ ^GSPC via yfinance
  download_vix_history()       1990+ VIX from CBOE
  download_recession_dates()   1854+ NBER recession flags
  download_fred_series()       1913+ macro indicators via FRED API

Phase 2  (background, days):
  download_nyt_archive()       1851+ financial headlines via NYT API
  download_gdelt_bulk()        2000+ global news with sentiment

Phase 3  (optional):
  download_sec_events()        1996+ earnings/economic events
  download_options_history()   2004+ SPY options snapshots
"""

from __future__ import annotations

import io
import os
import sqlite3
import sys
import time
import zipfile
from contextlib import contextmanager
from datetime import datetime, date, timezone
from pathlib import Path
from typing import Any

import requests

ROOT   = Path(__file__).resolve().parent.parent.parent
DB_DIR = ROOT / "database"
DB_DIR.mkdir(exist_ok=True)
HIST_DB = str(DB_DIR / "market_history.db")

# ── DB helpers ────────────────────────────────────────────────────────────────

@contextmanager
def _conn():
    c = sqlite3.connect(HIST_DB)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def _init_schema():
    with _conn() as c:
        c.executescript("""
            CREATE TABLE IF NOT EXISTS market_history (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                date     TEXT NOT NULL,
                source   TEXT NOT NULL,
                sp_price REAL, dividend REAL, earnings REAL,
                cpi      REAL, long_rate REAL, real_price REAL,
                open     REAL, high REAL, low REAL, close REAL, volume REAL,
                UNIQUE(date, source)
            );
            CREATE TABLE IF NOT EXISTS spy_prices (
                date   TEXT PRIMARY KEY,
                open   REAL, high REAL, low REAL, close REAL,
                volume REAL, source TEXT
            );
            CREATE TABLE IF NOT EXISTS vix_history (
                date  TEXT PRIMARY KEY,
                open  REAL, high REAL, low REAL, close REAL
            );
            CREATE TABLE IF NOT EXISTS recession_dates (
                date         TEXT PRIMARY KEY,
                in_recession INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS economic_indicators (
                date   TEXT NOT NULL,
                series TEXT NOT NULL,
                value  REAL,
                PRIMARY KEY (date, series)
            );
            CREATE TABLE IF NOT EXISTS economic_events (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                event_date  TEXT NOT NULL,
                event_type  TEXT NOT NULL,
                description TEXT,
                rate_change_bps REAL,
                source      TEXT
            );
            CREATE TABLE IF NOT EXISTS historical_news (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                pub_date    TEXT NOT NULL,
                headline    TEXT,
                abstract    TEXT,
                section     TEXT,
                source      TEXT,
                sentiment   REAL
            );
            CREATE TABLE IF NOT EXISTS options_history (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                date        TEXT NOT NULL,
                put_call_ratio REAL,
                implied_vol REAL,
                call_volume REAL,
                put_volume  REAL,
                source      TEXT
            );
            CREATE TABLE IF NOT EXISTS download_progress (
                task    TEXT PRIMARY KEY,
                last_completed TEXT,
                total_records  INTEGER DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_mh_date   ON market_history(date);
            CREATE INDEX IF NOT EXISTS idx_hn_date   ON historical_news(pub_date);
            CREATE INDEX IF NOT EXISTS idx_ei_series ON economic_indicators(series);
        """)


def _upsert_progress(task: str, last_completed: str, total: int = 0):
    with _conn() as c:
        c.execute("""
            INSERT INTO download_progress (task, last_completed, total_records)
            VALUES (?,?,?)
            ON CONFLICT(task) DO UPDATE SET
              last_completed=excluded.last_completed,
              total_records=download_progress.total_records + excluded.total_records
        """, (task, last_completed, total))


def _get_progress(task: str) -> str | None:
    with _conn() as c:
        row = c.execute(
            "SELECT last_completed FROM download_progress WHERE task=?", (task,)
        ).fetchone()
    return row["last_completed"] if row else None


# ── Phase 1 ───────────────────────────────────────────────────────────────────

def download_shiller_data() -> int:
    """Download Robert Shiller Yale dataset (1871+ monthly S&P data)."""
    _init_schema()
    print("  Downloading Shiller data (1871+)...")
    url = "http://www.econ.yale.edu/~shiller/data/ie_data.xls"
    try:
        import pandas as pd
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        df = pd.read_excel(io.BytesIO(resp.content), sheet_name="Data", header=7,
                           engine="xlrd")
        # Columns: Date, P (price), D (dividend), E (earnings), CPI, Rate GS10, Real Price...
        df = df.dropna(subset=[df.columns[0]])
        rows = []
        for _, row in df.iterrows():
            try:
                raw_date = str(row.iloc[0]).strip()
                # Format is YYYY.MM (e.g. 1871.01)
                parts = raw_date.split(".")
                year  = int(parts[0])
                month = int(parts[1]) if len(parts) > 1 else 1
                d = f"{year:04d}-{month:02d}-01"
                rows.append((
                    d, "shiller",
                    _float(row.iloc[1]),   # S&P price
                    _float(row.iloc[2]),   # dividend
                    _float(row.iloc[3]),   # earnings
                    _float(row.iloc[4]),   # CPI
                    _float(row.iloc[5]),   # 10y rate
                    _float(row.iloc[6]),   # real price
                ))
            except Exception:
                continue
        with _conn() as c:
            c.executemany("""
                INSERT OR IGNORE INTO market_history
                  (date,source,sp_price,dividend,earnings,cpi,long_rate,real_price)
                VALUES (?,?,?,?,?,?,?,?)
            """, rows)
        print(f"    Saved {len(rows)} monthly records (Shiller 1871+)")
        _upsert_progress("shiller", date.today().isoformat(), len(rows))
        return len(rows)
    except Exception as e:
        print(f"    Shiller download failed: {e}")
        return 0


def download_stooq_history() -> int:
    """Download DJIA (1896+) and SPX (1927+) daily from Stooq."""
    _init_schema()
    total = 0
    for symbol, label in [("^DJI", "djia"), ("^SPX", "spx")]:
        url = f"https://stooq.com/q/d/l/?s={symbol}&i=d"
        print(f"  Downloading Stooq {label.upper()} history...")
        try:
            import pandas as pd
            resp = requests.get(url, timeout=30)
            resp.raise_for_status()
            df = pd.read_csv(io.StringIO(resp.text), parse_dates=["Date"])
            rows = []
            for _, r in df.iterrows():
                rows.append((
                    str(r["Date"])[:10], label,
                    None, None, None, None, None, None,
                    _float(r.get("Open")), _float(r.get("High")),
                    _float(r.get("Low")),  _float(r.get("Close")),
                    _float(r.get("Volume")),
                ))
            with _conn() as c:
                c.executemany("""
                    INSERT OR IGNORE INTO market_history
                      (date,source,sp_price,dividend,earnings,cpi,long_rate,real_price,
                       open,high,low,close,volume)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, rows)
            print(f"    Saved {len(rows)} daily records ({label.upper()})")
            _upsert_progress(f"stooq_{label}", date.today().isoformat(), len(rows))
            total += len(rows)
        except Exception as e:
            print(f"    Stooq {label} download failed: {e}")
    return total


def download_spy_full() -> int:
    """Download full ^GSPC history via yfinance (1927+)."""
    _init_schema()
    print("  Downloading ^GSPC via yfinance (1927+)...")
    try:
        import yfinance as yf  # type: ignore
        import pandas as pd
        ticker = yf.Ticker("^GSPC")
        hist   = ticker.history(start="1927-01-01", period="max")
        rows = []
        for dt, row in hist.iterrows():
            rows.append((
                str(dt)[:10],
                _float(row.get("Open")), _float(row.get("High")),
                _float(row.get("Low")),  _float(row.get("Close")),
                _float(row.get("Volume")), "yfinance",
            ))
        with _conn() as c:
            c.executemany("""
                INSERT OR REPLACE INTO spy_prices (date,open,high,low,close,volume,source)
                VALUES (?,?,?,?,?,?,?)
            """, rows)
        print(f"    Saved {len(rows)} daily SPX records (yfinance)")
        _upsert_progress("yfinance_spx", date.today().isoformat(), len(rows))
        return len(rows)
    except ImportError:
        print("    yfinance not installed. Run: pip install yfinance")
        return 0
    except Exception as e:
        print(f"    yfinance download failed: {e}")
        return 0


def download_vix_history() -> int:
    """Download CBOE VIX daily history (1990+)."""
    _init_schema()
    print("  Downloading VIX history from CBOE (1990+)...")
    url = "https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX_History.csv"
    try:
        import pandas as pd
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        df = pd.read_csv(io.StringIO(resp.text))
        rows = []
        for _, r in df.iterrows():
            try:
                d = pd.to_datetime(r["DATE"]).strftime("%Y-%m-%d")
                rows.append((d, _float(r.get("OPEN")), _float(r.get("HIGH")),
                             _float(r.get("LOW")), _float(r.get("CLOSE"))))
            except Exception:
                continue
        with _conn() as c:
            c.executemany("""
                INSERT OR REPLACE INTO vix_history (date,open,high,low,close)
                VALUES (?,?,?,?,?)
            """, rows)
        print(f"    Saved {len(rows)} VIX records")
        _upsert_progress("vix", date.today().isoformat(), len(rows))
        return len(rows)
    except Exception as e:
        print(f"    VIX download failed: {e}")
        return 0


def download_recession_dates() -> int:
    """Download NBER recession indicators via FRED (1854+)."""
    _init_schema()
    print("  Downloading NBER recession dates via FRED (1854+)...")
    # Use USREC series from FRED (no API key needed for this endpoint)
    url = ("https://fred.stlouisfed.org/graph/fredgraph.csv"
           "?id=USREC&vintage_date=" + date.today().isoformat())
    try:
        import pandas as pd
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        df = pd.read_csv(io.StringIO(resp.text), parse_dates=["DATE"])
        rows = [(str(r["DATE"])[:10], int(r["USREC"])) for _, r in df.iterrows()]
        with _conn() as c:
            c.executemany("""
                INSERT OR REPLACE INTO recession_dates (date, in_recession)
                VALUES (?,?)
            """, rows)
        print(f"    Saved {len(rows)} recession date records")
        _upsert_progress("recession", date.today().isoformat(), len(rows))
        return len(rows)
    except Exception as e:
        print(f"    Recession dates download failed: {e}")
        return 0


def download_fred_series(api_key: str = "") -> int:
    """Download key FRED economic indicator series."""
    _init_schema()
    SERIES = {
        "SP500":         "S&P 500 Index",
        "VIXCLS":        "CBOE VIX",
        "FEDFUNDS":      "Federal Funds Rate",
        "CPIAUCSL":      "CPI Inflation",
        "UNRATE":        "Unemployment Rate",
        "GDP":           "GDP",
        "T10Y2Y":        "Yield Curve 10y-2y",
        "BAMLH0A0HYM2":  "High Yield Credit Spread",
        "M2SL":          "Money Supply M2",
        "INDPRO":        "Industrial Production",
        "USREC":         "NBER Recession Indicator",
    }
    if not api_key:
        api_key = os.environ.get("FRED_API_KEY", "")
    if not api_key:
        print("  FRED API key not set. Set FRED_API_KEY env var or pass api_key=.")
        print("  Free key at: https://fred.stlouisfed.org/docs/api/api_key.html")
        # Fall back to direct CSV (no key needed)
        return _download_fred_csv(SERIES)

    total = 0
    try:
        from fredapi import Fred  # type: ignore
        fred = Fred(api_key=api_key)
        for series_id, label in SERIES.items():
            try:
                print(f"  Downloading FRED {series_id} ({label})...")
                s = fred.get_series(series_id)
                rows = [(str(d)[:10], series_id, float(v))
                        for d, v in s.items() if v is not None and str(v) != "nan"]
                with _conn() as c:
                    c.executemany("""
                        INSERT OR REPLACE INTO economic_indicators (date, series, value)
                        VALUES (?,?,?)
                    """, rows)
                print(f"    Saved {len(rows)} records")
                total += len(rows)
                time.sleep(0.5)
            except Exception as e:
                print(f"    {series_id} failed: {e}")
        _upsert_progress("fred", date.today().isoformat(), total)
    except ImportError:
        print("  fredapi not installed. Run: pip install fredapi")
        total = _download_fred_csv(SERIES)
    return total


def _download_fred_csv(series: dict) -> int:
    """Fallback: download FRED series as CSV without API key."""
    total = 0
    for sid in series:
        url = f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={sid}"
        try:
            import pandas as pd
            resp = requests.get(url, timeout=20)
            if resp.status_code != 200:
                continue
            df = pd.read_csv(io.StringIO(resp.text))
            col = df.columns[1]
            rows = []
            for _, r in df.iterrows():
                try:
                    v = float(r[col])
                    rows.append((str(r.iloc[0])[:10], sid, v))
                except (ValueError, TypeError):
                    continue
            with _conn() as c:
                c.executemany("""
                    INSERT OR REPLACE INTO economic_indicators (date, series, value)
                    VALUES (?,?,?)
                """, rows)
            print(f"    {sid}: {len(rows)} records (CSV)")
            total += len(rows)
            time.sleep(1)
        except Exception as e:
            print(f"    {sid} CSV failed: {e}")
    return total


# ── Phase 2 ───────────────────────────────────────────────────────────────────

def download_nyt_archive(api_key: str, year_start: int = 1851,
                          year_end: int | None = None) -> int:
    """
    Download NYT article archive by month (1851+).
    Free API key: https://developer.nytimes.com
    Progress is saved so it can resume if interrupted.
    Rate limit: 5 req/min → 12s sleep between calls.
    """
    _init_schema()
    if not api_key:
        print("  NYT API key required. Get free key: https://developer.nytimes.com")
        return 0

    SECTIONS = {"Business", "Financial", "Economy", "Markets",
                "Business Day", "Politics", "U.S.", "World"}

    year_end = year_end or datetime.now().year
    progress_key = f"nyt_{year_start}_{year_end}"
    last = _get_progress(progress_key)
    start_year, start_month = year_start, 1
    if last:
        parts = last.split("-")
        start_year, start_month = int(parts[0]), int(parts[1])
        if start_month < 12:
            start_month += 1
        else:
            start_year += 1
            start_month = 1
        print(f"  Resuming NYT archive from {start_year}-{start_month:02d}...")

    total = 0
    for year in range(start_year, year_end + 1):
        for month in range(start_month if year == start_year else 1, 13):
            if year == datetime.now().year and month > datetime.now().month:
                break
            url = (f"https://api.nytimes.com/svc/archive/v1/"
                   f"{year}/{month}.json?api-key={api_key}")
            try:
                resp = requests.get(url, timeout=30)
                if resp.status_code == 429:
                    print(f"    Rate limited at {year}-{month:02d}, sleeping 60s...")
                    time.sleep(60)
                    resp = requests.get(url, timeout=30)
                resp.raise_for_status()
                docs = resp.json().get("response", {}).get("docs", [])
                rows = []
                for d in docs:
                    sec = (d.get("section_name") or "")
                    if sec not in SECTIONS:
                        continue
                    rows.append((
                        (d.get("pub_date") or "")[:10],
                        d.get("headline", {}).get("main", ""),
                        d.get("abstract", ""),
                        sec,
                        "nyt",
                        None,
                    ))
                if rows:
                    with _conn() as c:
                        c.executemany("""
                            INSERT INTO historical_news
                              (pub_date,headline,abstract,section,source,sentiment)
                            VALUES (?,?,?,?,?,?)
                        """, rows)
                total += len(rows)
                _upsert_progress(progress_key, f"{year}-{month:02d}", len(rows))
                print(f"    {year}-{month:02d}: {len(rows)} articles (total {total})")
            except Exception as e:
                print(f"    {year}-{month:02d} failed: {e}")

            time.sleep(12)   # 5 req/min rate limit

    return total


def download_nyt_batch(api_key: str, year_start: int, year_end: int) -> int:
    """Convenience wrapper for running NYT download in date-range batches."""
    return download_nyt_archive(api_key, year_start, year_end)


def download_gdelt_bulk(start_date: str = "2000-01-01",
                         end_date: str | None = None) -> int:
    """
    Download GDELT 2.0 bulk export files filtered to financial events.
    Saves to historical_news with source='gdelt'.
    Note: files are large (~100MB each); filtered rows only saved.
    """
    _init_schema()
    print("  GDELT bulk download is a long-running operation.")
    print("  Each 15-min file is ~5-20 MB; running from", start_date)
    FINANCIAL_THEMES = {"ECON_", "BUS_", "FIN_"}
    FINANCIAL_ACTORS = {"SPY", "S&P", "FED", "FEDERAL RESERVE", "WALL STREET",
                        "NASDAQ", "DOW JONES", "TREASURY"}

    # GDELT master file list
    master_url = "http://data.gdeltproject.org/gdeltv2/masterfilelist.txt"
    try:
        resp = requests.get(master_url, timeout=30)
        lines = resp.text.strip().split("\n")
        # Each line: size hash url
        export_urls = [l.split()[-1] for l in lines
                       if "export.CSV.zip" in l and l.split()[-1] >= start_date.replace("-","")]
        progress_key = "gdelt"
        last = _get_progress(progress_key) or ""
        export_urls = [u for u in export_urls if u > last]

        total = 0
        for url in export_urls[:100]:  # cap at 100 files per run
            try:
                r = requests.get(url, timeout=60)
                with zipfile.ZipFile(io.BytesIO(r.content)) as z:
                    csv_name = z.namelist()[0]
                    with z.open(csv_name) as f:
                        lines = f.read().decode("utf-8", errors="replace").split("\n")
                rows = []
                for line in lines:
                    cols = line.split("\t")
                    if len(cols) < 60:
                        continue
                    themes   = cols[10] if len(cols) > 10 else ""
                    actor1   = (cols[6] if len(cols) > 6 else "").upper()
                    headline = cols[57] if len(cols) > 57 else ""
                    pub_date = cols[1][:8] if len(cols) > 1 else ""
                    if not (any(t in themes for t in FINANCIAL_THEMES) or
                            any(a in actor1 for a in FINANCIAL_ACTORS) or
                            any(a in headline.upper() for a in FINANCIAL_ACTORS)):
                        continue
                    if len(pub_date) == 8:
                        pub_date = f"{pub_date[:4]}-{pub_date[4:6]}-{pub_date[6:8]}"
                    rows.append((pub_date, headline[:500], "", "news", "gdelt", None))
                if rows:
                    with _conn() as c:
                        c.executemany("""
                            INSERT INTO historical_news
                              (pub_date,headline,abstract,section,source,sentiment)
                            VALUES (?,?,?,?,?,?)
                        """, rows)
                total += len(rows)
                _upsert_progress(progress_key, url, len(rows))
                print(f"    GDELT {url[-20:]}: {len(rows)} fin. events")
            except Exception as e:
                print(f"    GDELT file failed: {e}")
        return total
    except Exception as e:
        print(f"  GDELT master list failed: {e}")
        return 0


# ── Phase 3 ───────────────────────────────────────────────────────────────────

def download_vix_options_history() -> int:
    """Download Polygon.io free-tier SPY options data (last 2 years)."""
    _init_schema()
    api_key = os.environ.get("POLYGON_API_KEY", "")
    if not api_key:
        print("  POLYGON_API_KEY not set. Free key: https://polygon.io/dashboard")
        return 0
    # Placeholder — full implementation uses Polygon /v3/reference/options/contracts
    print("  Polygon options history: set POLYGON_API_KEY to enable.")
    return 0


# ── helpers ───────────────────────────────────────────────────────────────────

def _float(v) -> float | None:
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None


# ── Phase 1 master runner ─────────────────────────────────────────────────────

def run_phase1() -> None:
    """Run all Phase 1 downloads (~30 min). Safe to re-run (idempotent)."""
    print("\n=== CEREBRO HISTORICAL DATA — PHASE 1 ===\n")
    t0 = time.time()
    n  = 0
    n += download_shiller_data()
    n += download_stooq_history()
    n += download_spy_full()
    n += download_vix_history()
    n += download_recession_dates()
    n += download_fred_series()
    elapsed = (time.time() - t0) / 60
    print(f"\n=== Phase 1 complete: {n:,} total records in {elapsed:.1f} min ===\n")


if __name__ == "__main__":
    run_phase1()
