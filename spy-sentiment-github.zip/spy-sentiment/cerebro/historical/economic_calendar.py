"""
economic_calendar.py — High-impact event awareness and signal adjustment.

get_upcoming_events()         → next N days of market-moving events
adjust_signal_for_calendar()  → reduce position size near high-impact dates
historical_event_behavior()   → how SPY behaved around this event type
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

ROOT    = Path(__file__).resolve().parent.parent.parent
HIST_DB = str(ROOT / "database" / "market_history.db")

HIGH_IMPACT_EVENTS = [
    "FOMC_DECISION", "FOMC_MINUTES", "FED_CHAIR_SPEECH",
    "CPI_RELEASE",   "PPI_RELEASE",  "PCE_RELEASE",
    "NFP_JOBS_REPORT", "UNEMPLOYMENT_RATE",
    "GDP_ADVANCE",   "GDP_REVISED",
    "RETAIL_SALES",  "ISM_MANUFACTURING",
    "EARNINGS_SEASON_START",
    "OPTIONS_EXPIRATION",
    "TRIPLE_WITCHING",
    "DEBT_CEILING_DEADLINE",
    "ELECTION_DAY",
    "GOVERNMENT_SHUTDOWN",
]

# ── Pre-computed size-reduction rules ─────────────────────────────────────────
_SIZE_REDUCTION: dict[str, float] = {
    "FOMC_DECISION":       0.50,
    "CPI_RELEASE":         0.30,
    "NFP_JOBS_REPORT":     0.30,
    "PCE_RELEASE":         0.25,
    "GDP_ADVANCE":         0.20,
    "TRIPLE_WITCHING":     0.20,
    "OPTIONS_EXPIRATION":  0.15,
    "FOMC_MINUTES":        0.15,
    "EARNINGS_SEASON_START": 0.10,
}

# ── Historical pre/post event behaviour ───────────────────────────────────────
_EVENT_BEHAVIOR: dict[str, dict] = {
    "FOMC_DECISION": {
        "pre":  "SPY avg flat -0.1%, VIX rises ~8% in 2 days before",
        "post": "Large move day-of (+/-1.2% avg); direction depends on surprise",
        "spy_avg_move_post_1d": 0.0,
        "vix_avg_move_pre":     8.0,
    },
    "CPI_RELEASE": {
        "pre":  "SPY sideways-to-down, VIX +5% day before",
        "post": "Hot CPI: SPY -1.0%; Cool CPI: SPY +1.5%",
        "spy_avg_move_post_1d": -0.2,
        "vix_avg_move_pre":     5.0,
    },
    "NFP_JOBS_REPORT": {
        "pre":  "Low volume Thursday before; gap risk Friday morning",
        "post": "Avg move ±0.8%; strong jobs = rate fear; weak = recession fear",
        "spy_avg_move_post_1d": 0.1,
        "vix_avg_move_pre":     4.0,
    },
    "TRIPLE_WITCHING": {
        "pre":  "Increased volatility week of; pin risk at large OI strikes",
        "post": "Mean reversion common Monday after",
        "spy_avg_move_post_1d": 0.0,
        "vix_avg_move_pre":     3.0,
    },
    "OPTIONS_EXPIRATION": {
        "pre":  "Gamma exposure max Fri morning; price pins to large OI",
        "post": "Dealers re-hedge after expiry; direction open",
        "spy_avg_move_post_1d": 0.1,
        "vix_avg_move_pre":     2.0,
    },
}


# ── DB helpers ─────────────────────────────────────────────────────────────────

@contextmanager
def _conn():
    c = sqlite3.connect(HIST_DB)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def _init():
    with _conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS calendar_events (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                event_date  TEXT NOT NULL,
                event_type  TEXT NOT NULL,
                description TEXT,
                forecast    TEXT,
                previous    TEXT,
                impact      TEXT DEFAULT 'HIGH'
            )
        """)
        c.execute("CREATE INDEX IF NOT EXISTS idx_cal_date ON calendar_events(event_date)")


# ── calendar helpers ──────────────────────────────────────────────────────────

def _is_third_friday(d: date) -> bool:
    """True if d is the 3rd Friday of its month."""
    return d.weekday() == 4 and 15 <= d.day <= 21


def _is_triple_witching(d: date) -> bool:
    """True if d is the 3rd Friday of March, June, September, or December."""
    return _is_third_friday(d) and d.month in (3, 6, 9, 12)


def _earnings_season_start(d: date) -> bool:
    """Earnings seasons start ~2nd week of Jan, Apr, Jul, Oct."""
    return d.month in (1, 4, 7, 10) and 8 <= d.day <= 16


def _generate_mechanical_events(days_ahead: int = 90) -> list[dict]:
    """Generate known recurring events without scraping."""
    events = []
    today = date.today()
    for offset in range(days_ahead):
        d = today + timedelta(days=offset)
        ds = d.isoformat()
        if _is_triple_witching(d):
            events.append({"event_date": ds, "event_type": "TRIPLE_WITCHING",
                            "description": "Quarterly triple witching expiration",
                            "impact": "HIGH"})
        elif _is_third_friday(d):
            events.append({"event_date": ds, "event_type": "OPTIONS_EXPIRATION",
                            "description": "Monthly options expiration",
                            "impact": "MEDIUM"})
        if _earnings_season_start(d):
            events.append({"event_date": ds, "event_type": "EARNINGS_SEASON_START",
                            "description": "Earnings season begins",
                            "impact": "MEDIUM"})
    return events


# ── public API ────────────────────────────────────────────────────────────────

def get_upcoming_events(days_ahead: int = 30) -> list[dict]:
    """
    Return upcoming high-impact events for the next `days_ahead` days,
    combining stored events + mechanical calendar events.
    """
    _init()
    cutoff = (date.today() + timedelta(days=days_ahead)).isoformat()
    today_s = date.today().isoformat()

    stored: list[dict] = []
    try:
        with _conn() as c:
            rows = c.execute("""
                SELECT * FROM calendar_events
                WHERE event_date >= ? AND event_date <= ?
                ORDER BY event_date
            """, (today_s, cutoff)).fetchall()
        stored = [dict(r) for r in rows]
    except Exception:
        pass

    mechanical = _generate_mechanical_events(days_ahead)
    stored_dates_types = {(e["event_date"], e["event_type"]) for e in stored}
    for m in mechanical:
        if (m["event_date"], m["event_type"]) not in stored_dates_types:
            stored.append(m)

    return sorted(stored, key=lambda e: e["event_date"])


def adjust_signal_for_calendar(signal: str, current_date: date | None = None) -> dict:
    """
    Reduce position size and add warnings based on upcoming calendar events.

    Returns:
        adjusted_signal : str (same as input)
        size_multiplier : float (1.0 = full size, 0.5 = half size)
        warnings        : list[str]
    """
    _init()
    today = current_date or date.today()
    upcoming = get_upcoming_events(days_ahead=3)

    size_multiplier = 1.0
    warnings: list[str] = []

    for event in upcoming:
        event_date = date.fromisoformat(event["event_date"])
        days_away  = (event_date - today).days
        etype      = event["event_type"]

        if etype in _SIZE_REDUCTION and days_away <= 2:
            reduction = _SIZE_REDUCTION[etype]
            size_multiplier = min(size_multiplier, 1.0 - reduction)
            warnings.append(
                f"{etype} in {days_away}d — size reduced by {int(reduction*100)}%"
            )

        if etype == "TRIPLE_WITCHING" and days_away <= 5:
            warnings.append("Triple witching this week — widen stop losses")

        if etype == "EARNINGS_SEASON_START" and days_away <= 3:
            warnings.append("Earnings season starting — increased vol expected")

    return {
        "adjusted_signal": signal,
        "size_multiplier": round(size_multiplier, 2),
        "warnings":        warnings,
    }


def historical_event_behavior(event_type: str) -> dict:
    """Return pre/post market behaviour for a known event type."""
    return _EVENT_BEHAVIOR.get(event_type, {
        "pre":  "No specific historical pattern on record.",
        "post": "No specific historical pattern on record.",
    })


def days_to_next(event_type: str) -> int | None:
    """Return days until the next occurrence of event_type, or None."""
    events = get_upcoming_events(days_ahead=60)
    for e in events:
        if e["event_type"] == event_type:
            return (date.fromisoformat(e["event_date"]) - date.today()).days
    return None
