"""
pattern_library.py — Named recurring market patterns with historical profiles.

For each pattern:
  - Find all historical instances
  - Calculate avg SPY move 1d / 3d / 1wk / 1mo after
  - Calculate win rate for calls vs puts
  - Classify current headline into a pattern
"""

from __future__ import annotations

import re
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any

ROOT    = Path(__file__).resolve().parent.parent.parent
HIST_DB = str(ROOT / "database" / "market_history.db")

# ── Pattern definitions ───────────────────────────────────────────────────────

KNOWN_PATTERNS = [
    "fed_rate_hike_surprise",
    "fed_rate_cut_surprise",
    "fed_pivot_signal",
    "inflation_spike",
    "recession_confirmed",
    "banking_crisis",
    "war_outbreak",
    "war_resolution",
    "pandemic_shock",
    "debt_ceiling_crisis",
    "earnings_season_strong",
    "earnings_season_weak",
    "yield_curve_inversion",
    "vix_spike_above_30",
    "short_squeeze",
    "oil_price_shock",
    "dollar_strength_spike",
    "tech_sector_selloff",
    "flight_to_safety",
]

# keyword sets for each pattern (used for fast text classification)
_PATTERN_KEYWORDS: dict[str, list[str]] = {
    "fed_rate_hike_surprise":  ["fed hike", "rate hike", "bps hike", "raises rates", "tightening"],
    "fed_rate_cut_surprise":   ["fed cut", "rate cut", "bps cut", "lowers rates", "easing"],
    "fed_pivot_signal":        ["fed pivot", "pause hikes", "rate pause", "done hiking", "powell pivot"],
    "inflation_spike":         ["cpi surges", "inflation hits", "inflation rises", "hot inflation", "core cpi"],
    "recession_confirmed":     ["recession", "two quarters", "gdp contraction", "economic contraction"],
    "banking_crisis":          ["bank failure", "bank run", "bank collapse", "fdic", "bailout", "svb", "lehman"],
    "war_outbreak":            ["war breaks", "invasion", "military conflict", "troops invade", "airstrikes"],
    "war_resolution":          ["ceasefire", "peace deal", "war ends", "troops withdraw"],
    "pandemic_shock":          ["pandemic", "epidemic", "outbreak", "lockdown", "covid", "virus spreads"],
    "debt_ceiling_crisis":     ["debt ceiling", "debt limit", "default risk", "treasury default"],
    "earnings_season_strong":  ["earnings beat", "strong earnings", "record earnings", "eps beats"],
    "earnings_season_weak":    ["earnings miss", "weak earnings", "disappoints", "eps misses", "guidance cut"],
    "yield_curve_inversion":   ["yield curve inverts", "inverted yield", "10-2 spread", "curve inversion"],
    "vix_spike_above_30":      ["vix spikes", "vix above 30", "volatility surges", "fear index"],
    "short_squeeze":           ["short squeeze", "meme stock", "gme", "apes", "reddit rally"],
    "oil_price_shock":         ["oil surges", "oil spikes", "crude spikes", "energy crisis", "opec cut"],
    "dollar_strength_spike":   ["dollar surges", "dxy spikes", "dollar strength", "strong dollar"],
    "tech_sector_selloff":     ["tech selloff", "nasdaq falls", "growth stocks", "tech rout"],
    "flight_to_safety":        ["flight to safety", "risk-off", "gold surges", "treasuries rally"],
}

# Historical average SPY reaction (manually researched; DB overrides if data available)
_HISTORICAL_PROFILES: dict[str, dict] = {
    "fed_rate_hike_surprise":  {"avg_1d": -0.8,  "avg_1wk": -1.5, "avg_1mo": -2.1, "call_win_pct": 28},
    "fed_rate_cut_surprise":   {"avg_1d": +1.2,  "avg_1wk": +2.0, "avg_1mo": +3.5, "call_win_pct": 68},
    "fed_pivot_signal":        {"avg_1d": +1.5,  "avg_1wk": +3.2, "avg_1mo": +6.8, "call_win_pct": 75},
    "inflation_spike":         {"avg_1d": -1.0,  "avg_1wk": -1.8, "avg_1mo": -2.5, "call_win_pct": 30},
    "recession_confirmed":     {"avg_1d": -1.8,  "avg_1wk": -3.5, "avg_1mo": -5.0, "call_win_pct": 20},
    "banking_crisis":          {"avg_1d": -2.5,  "avg_1wk": -4.0, "avg_1mo": -6.0, "call_win_pct": 18},
    "war_outbreak":            {"avg_1d": -1.5,  "avg_1wk": -2.0, "avg_1mo": +0.5, "call_win_pct": 35},
    "war_resolution":          {"avg_1d": +1.0,  "avg_1wk": +2.0, "avg_1mo": +3.0, "call_win_pct": 65},
    "pandemic_shock":          {"avg_1d": -4.0,  "avg_1wk": -8.0, "avg_1mo":-15.0, "call_win_pct": 10},
    "debt_ceiling_crisis":     {"avg_1d": -0.5,  "avg_1wk": -1.0, "avg_1mo": +1.0, "call_win_pct": 45},
    "earnings_season_strong":  {"avg_1d": +0.8,  "avg_1wk": +1.5, "avg_1mo": +3.0, "call_win_pct": 64},
    "earnings_season_weak":    {"avg_1d": -0.9,  "avg_1wk": -1.8, "avg_1mo": -2.5, "call_win_pct": 32},
    "yield_curve_inversion":   {"avg_1d": -0.3,  "avg_1wk": -0.5, "avg_1mo": -0.8, "call_win_pct": 42},
    "vix_spike_above_30":      {"avg_1d": -2.0,  "avg_1wk": -1.5, "avg_1mo": +2.0, "call_win_pct": 38},
    "short_squeeze":           {"avg_1d": +1.5,  "avg_1wk": +0.5, "avg_1mo": +0.0, "call_win_pct": 55},
    "oil_price_shock":         {"avg_1d": -0.8,  "avg_1wk": -1.0, "avg_1mo": -1.5, "call_win_pct": 35},
    "dollar_strength_spike":   {"avg_1d": -0.6,  "avg_1wk": -1.2, "avg_1mo": -1.8, "call_win_pct": 38},
    "tech_sector_selloff":     {"avg_1d": -1.2,  "avg_1wk": -2.0, "avg_1mo": -1.5, "call_win_pct": 30},
    "flight_to_safety":        {"avg_1d": -1.0,  "avg_1wk": -1.5, "avg_1mo": -0.5, "call_win_pct": 33},
}


# ── classification ────────────────────────────────────────────────────────────

def classify_current_news(headline: str,
                           sentiment_score: float = 0.0) -> dict[str, Any]:
    """
    Classify a headline into a known market pattern.

    Returns dict with:
      pattern_name        : str  (or "unclassified")
      pattern_profile     : dict (avg moves, win rate)
      signal_adjustment   : str  ("BULLISH" / "BEARISH" / "NEUTRAL")
    """
    text = headline.lower()
    matches: list[tuple[str, int]] = []
    for pattern, keywords in _PATTERN_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in text)
        if score > 0:
            matches.append((pattern, score))

    if not matches:
        return {
            "pattern_name":    "unclassified",
            "pattern_profile": None,
            "signal_adjustment": _score_to_signal(sentiment_score),
        }

    best_pattern = max(matches, key=lambda x: x[1])[0]
    profile = _HISTORICAL_PROFILES.get(best_pattern, {})

    # Determine signal from historical profile
    avg_1d = profile.get("avg_1d", 0.0)
    call_wp = profile.get("call_win_pct", 50)
    if call_wp >= 60 and avg_1d > 0:
        sig = "BULLISH"
    elif call_wp <= 35 or avg_1d < -1.0:
        sig = "BEARISH"
    else:
        sig = "NEUTRAL"

    return {
        "pattern_name":     best_pattern,
        "pattern_profile":  profile,
        "signal_adjustment": sig,
    }


def _score_to_signal(score: float) -> str:
    if score > 0.15:
        return "BULLISH"
    if score < -0.15:
        return "BEARISH"
    return "NEUTRAL"


# ── DB-backed profile builder ─────────────────────────────────────────────────

@contextmanager
def _conn():
    c = sqlite3.connect(HIST_DB)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def _init_pattern_table():
    with _conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS pattern_library (
                pattern_name   TEXT PRIMARY KEY,
                instance_count INTEGER DEFAULT 0,
                avg_move_1d    REAL,
                avg_move_1wk   REAL,
                avg_move_1mo   REAL,
                call_win_pct   REAL,
                last_updated   TEXT
            )
        """)


def build_pattern_profile(pattern_name: str) -> dict:
    """
    Build an empirical profile for a pattern by scanning historical_news
    and matching aligned spy_prices records.
    Falls back to hard-coded _HISTORICAL_PROFILES if insufficient data.
    """
    _init_pattern_table()
    keywords = _PATTERN_KEYWORDS.get(pattern_name, [])
    if not keywords:
        return {}

    # Build a regex matching any keyword
    pattern_re = "|".join(re.escape(k) for k in keywords)

    try:
        with _conn() as c:
            matches = c.execute("""
                SELECT pub_date FROM historical_news
                WHERE LOWER(headline) REGEXP ?
                ORDER BY pub_date
            """, (pattern_re,)).fetchall()
    except Exception:
        # REGEXP not supported without extension; use LIKE instead
        try:
            with _conn() as c:
                conditions = " OR ".join(
                    f"LOWER(headline) LIKE '%{k}%'" for k in keywords[:5]
                )
                matches = c.execute(
                    f"SELECT pub_date FROM historical_news WHERE {conditions} ORDER BY pub_date"
                ).fetchall()
        except Exception:
            matches = []

    if len(matches) < 3:
        # Not enough data — use static profile
        profile = _HISTORICAL_PROFILES.get(pattern_name, {})
        return {"pattern_name": pattern_name, "source": "static", **profile}

    moves_1d, moves_1wk = [], []
    try:
        with _conn() as c:
            for row in matches:
                event_date = row["pub_date"]
                prices = c.execute("""
                    SELECT date, close FROM spy_prices
                    WHERE date >= ? ORDER BY date LIMIT 25
                """, (event_date,)).fetchall()
                if len(prices) < 2:
                    continue
                entry = prices[0]["close"]
                if entry and entry > 0:
                    day1 = prices[1]["close"] if len(prices) > 1 else None
                    day5 = prices[5]["close"] if len(prices) > 5 else None
                    if day1:
                        moves_1d.append((day1 - entry) / entry * 100)
                    if day5:
                        moves_1wk.append((day5 - entry) / entry * 100)
    except Exception:
        pass

    avg_1d  = round(sum(moves_1d) / len(moves_1d), 2) if moves_1d else None
    avg_1wk = round(sum(moves_1wk) / len(moves_1wk), 2) if moves_1wk else None
    call_wp = round(sum(1 for m in moves_1d if m > 0) / len(moves_1d) * 100, 1) if moves_1d else None

    profile = {
        "avg_move_1d":   avg_1d,
        "avg_move_1wk":  avg_1wk,
        "call_win_pct":  call_wp,
        "instance_count": len(matches),
        "source": "empirical",
    }

    # Persist
    from datetime import date
    _init_pattern_table()
    with _conn() as c:
        c.execute("""
            INSERT OR REPLACE INTO pattern_library
              (pattern_name, instance_count, avg_move_1d, avg_move_1wk, call_win_pct, last_updated)
            VALUES (?,?,?,?,?,?)
        """, (pattern_name, len(matches), avg_1d, avg_1wk, call_wp,
               date.today().isoformat()))

    return {"pattern_name": pattern_name, **profile}


def build_all_profiles() -> None:
    """Build empirical profiles for all known patterns."""
    _init_pattern_table()
    for p in KNOWN_PATTERNS:
        print(f"  Building profile: {p}")
        profile = build_pattern_profile(p)
        print(f"    instances={profile.get('instance_count',0)}  "
              f"avg1d={profile.get('avg_move_1d')}  "
              f"call_wp={profile.get('call_win_pct')}%")


def get_profile(pattern_name: str) -> dict:
    """Fetch a pattern profile (DB-backed then static fallback)."""
    _init_pattern_table()
    try:
        with _conn() as c:
            row = c.execute(
                "SELECT * FROM pattern_library WHERE pattern_name=?",
                (pattern_name,),
            ).fetchone()
        if row:
            return dict(row)
    except Exception:
        pass
    return _HISTORICAL_PROFILES.get(pattern_name, {})
