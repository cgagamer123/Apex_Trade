"""
run_all_v2.py — Master runner for all historical data phases.

Usage:
    python cerebro/historical/run_all_v2.py --phase 1
    python cerebro/historical/run_all_v2.py --phase 2 --nyt-key YOUR_KEY
    python cerebro/historical/run_all_v2.py --train
    python cerebro/historical/run_all_v2.py --all
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT))

from cerebro.historical.deep_history_collector import (
    run_phase1,
    download_nyt_batch,
    download_gdelt_bulk,
)
from cerebro.historical.era_classifier import label_all_dates_with_era
from cerebro.historical.pattern_library import build_all_profiles
from cerebro.historical.cerebro_trainer_v2 import build_mega_dataset, train_ensemble


def phase1() -> None:
    print("\n" + "="*55)
    print("  PHASE 1 — Market price + macro data (< 30 min)")
    print("="*55)
    run_phase1()
    print("\n  Labelling all dates with era/regime context...")
    label_all_dates_with_era()
    print("  Phase 1 complete.")


def phase2(nyt_key: str = "", year_start: int = 1851) -> None:
    print("\n" + "="*55)
    print("  PHASE 2 — News archive (background, may take days)")
    print("="*55)
    if nyt_key:
        # Split into manageable batches
        batches = [(1851, 1900), (1901, 1950), (1951, 1990),
                   (1991, 2010), (2011, 2024)]
        for start, end in batches:
            if start < year_start:
                continue
            print(f"\n  Batch: {start}–{end}")
            n = download_nyt_batch(nyt_key, start, end)
            print(f"    {n:,} articles saved")
    else:
        print("  NYT API key not provided — skipping NYT archive.")
        print("  Set with: --nyt-key YOUR_KEY")

    print("\n  Downloading GDELT bulk (2000+)...")
    n = download_gdelt_bulk()
    print(f"  GDELT: {n:,} records saved")


def phase3_train() -> None:
    print("\n" + "="*55)
    print("  PHASE 3 — Pattern profiles + model training")
    print("="*55)
    print("\n  Building pattern library profiles...")
    build_all_profiles()

    print("\n  Building feature dataset...")
    df = build_mega_dataset()

    if len(df) < 100:
        print("  Not enough data to train. Run Phase 1 first.")
        return

    print("\n  Training ensemble model...")
    metrics = train_ensemble(df)

    print("\n  Final metrics:")
    for k, v in metrics.items():
        print(f"    {k}: {v:.1%}" if isinstance(v, float) else f"    {k}: {v}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Cerebro Historical Data Runner")
    parser.add_argument("--phase", type=int, choices=[1, 2], help="Run phase 1 or 2")
    parser.add_argument("--train", action="store_true", help="Train models (Phase 3)")
    parser.add_argument("--all",   action="store_true", help="Run all phases + train")
    parser.add_argument("--nyt-key", default=os.environ.get("NYT_API_KEY",""),
                        help="NYT Archive API key")
    parser.add_argument("--year-start", type=int, default=1851)
    parser.add_argument("--fred-key",   default=os.environ.get("FRED_API_KEY",""),
                        help="FRED API key (optional — has free CSV fallback)")
    args = parser.parse_args()

    if args.fred_key:
        os.environ["FRED_API_KEY"] = args.fred_key

    t0 = time.time()

    if args.all:
        phase1()
        phase2(args.nyt_key, args.year_start)
        phase3_train()
    elif args.phase == 1:
        phase1()
    elif args.phase == 2:
        phase2(args.nyt_key, args.year_start)
    elif args.train:
        phase3_train()
    else:
        parser.print_help()
        print("\n  Quick start:  python run_all_v2.py --phase 1")
        return

    elapsed = (time.time() - t0) / 60
    print(f"\n  Total time: {elapsed:.1f} min")
    print("  Done.")


if __name__ == "__main__":
    main()
