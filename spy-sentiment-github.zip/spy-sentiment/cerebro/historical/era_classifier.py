"""
era_classifier.py — Tags every historical date with market era, regime, and context.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import date, datetime
from pathlib import Path
from typing import Optional

ROOT    = Path(__file__).resolve().parent.parent.parent
HIST_DB = str(ROOT / "database" / "market_history.db")

# ── Market eras ───────────────────────────────────────────────────────────────

MARKET_ERAS: dict[str, tuple[str, str | None]] = {
    "panic_of_1907":     ("1907-10-01", "1908-06-01"),
    "ww1_shock":         ("1914-07-01", "1918-11-01"),
    "roaring_twenties":  ("1921-01-01", "1929-09-01"),
    "great_depression":  ("1929-10-01", "1933-03-01"),
    "ww2_uncertainty":   ("1939-09-01", "1945-08-01"),
    "postwar_boom":      ("1945-09-01", "1966-01-01"),
    "stagflation":       ("1966-01-01", "1982-08-01"),
    "great_bull_market": ("1982-08-01", "2000-03-01"),
    "dotcom_crash":      ("2000-03-01", "2002-10-01"),
    "housing_boom":      ("2002-10-01", "2007-10-01"),
    "financial_crisis":  ("2007-10-01", "2009-03-01"),
    "qe_bull_market":    ("2009-03-01", "2020-02-01"),
    "covid_crash":       ("2020-02-01", "2020-04-01"),
    "covid_recovery":    ("2020-04-01", "2022-01-01"),
    "rate_hike_bear":    ("2022-01-01", "2023-10-01"),
    "ai_bull_market":    ("2023-10-01", None),
}


def classify_era(dt: str) -> str:
    """Return era name for a date string YYYY-MM-DD."""
    for era, (start, end) in MARKET_ERAS.items():
        if dt >= start and (end is None or dt < end):
            return era
    return "pre_modern"


# ── VIX regime ────────────────────────────────────────────────────────────────

def vix_regime(vix: float | None) -> str:
    if vix is None:
        return "unknown"
    if vix < 15:
        return "low"
    if vix < 25:
        return "medium"
    if vix < 35:
        return "high"
    return "crisis"


# ── Fed rate environment ──────────────────────────────────────────────────────

def fed_environment(rates: list[tuple[str, float]]) -> str:
    """
    Given a sorted list of (date, fed_funds_rate) return trend:
    hiking / cutting / holding.
    Compares last 6 months of data.
    """
    if len(rates) < 2:
        return "unknown"
    recent = rates[-1][1]
    past   = rates[max(0, len(rates) - 6)][1]
    delta  = recent - past
    if delta > 0.25:
        return "hiking"
    if delta < -0.25:
        return "cutting"
    return "holding"


# ── DB label helpers ──────────────────────────────────────────────────────────

@contextmanager
def _conn():
    c = sqlite3.connect(HIST_DB)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def label_all_dates_with_era() -> int:
    """
    Add era_label, is_recession, vix_regime, fed_environment columns to
    market_history, spy_prices, and historical_news tables where missing.
    """
    tables_to_alter = [
        ("market_history", "date"),
        ("spy_prices",     "date"),
        ("historical_news","pub_date"),
    ]
    updated = 0
    try:
        with _conn() as c:
            # Add columns if they don't exist
            for table, _ in tables_to_alter:
                for col, typ in [("era_label", "TEXT"), ("is_recession", "INTEGER"),
                                 ("vix_regime_label", "TEXT"), ("fed_env", "TEXT"),
                                 ("is_bull_market", "INTEGER"), ("is_bear_market", "INTEGER")]:
                    try:
                        c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
                    except Exception:
                        pass   # column already exists

            # Load recession dates
            rec_rows = c.execute("SELECT date, in_recession FROM recession_dates").fetchall()
            rec_map: dict[str, int] = {r["date"]: r["in_recession"] for r in rec_rows}

            # Load VIX
            vix_rows = c.execute("SELECT date, close FROM vix_history").fetchall()
            vix_map: dict[str, float] = {r["date"]: r["close"] for r in vix_rows}

            # Load fed funds
            ff_rows = c.execute(
                "SELECT date, value FROM economic_indicators WHERE series='FEDFUNDS' ORDER BY date"
            ).fetchall()
            ff_list = [(r["date"], r["value"]) for r in ff_rows]

            def _fed_env_at(dt: str) -> str:
                idx = next((i for i, (d, _) in enumerate(ff_list) if d >= dt), None)
                if idx is None:
                    return "unknown"
                slice_ = ff_list[max(0, idx - 6): idx + 1]
                return fed_environment(slice_)

            bear_eras = {"great_depression", "dotcom_crash", "financial_crisis",
                         "covid_crash", "rate_hike_bear", "ww1_shock",
                         "stagflation", "ww2_uncertainty", "panic_of_1907"}
            bull_eras = {"roaring_twenties", "postwar_boom", "great_bull_market",
                         "housing_boom", "qe_bull_market", "covid_recovery",
                         "ai_bull_market"}

            for table, date_col in tables_to_alter:
                rows = c.execute(f"SELECT rowid, {date_col} FROM {table}").fetchall()
                batch = []
                for row in rows:
                    dt   = str(row[date_col])[:10]
                    era  = classify_era(dt)
                    rec  = rec_map.get(dt, 0)
                    vix  = vix_map.get(dt)
                    vr   = vix_regime(vix)
                    fed  = _fed_env_at(dt)
                    bull = 1 if era in bull_eras else 0
                    bear = 1 if era in bear_eras else 0
                    batch.append((era, rec, vr, fed, bull, bear, row["rowid"]))
                c.executemany(f"""
                    UPDATE {table} SET era_label=?, is_recession=?, vix_regime_label=?,
                    fed_env=?, is_bull_market=?, is_bear_market=? WHERE rowid=?
                """, batch)
                updated += len(batch)
                print(f"    Labelled {len(batch)} rows in {table}")
    except Exception as e:
        print(f"  Era labelling failed: {e}")
    return updated


def get_current_era() -> dict:
    """Return era info for today."""
    today = date.today().isoformat()
    era   = classify_era(today)
    start, end = MARKET_ERAS.get(era, (today, None))
    similar_history = _what_happened_in_era(era)
    return {
        "era":           era,
        "start":         start,
        "end":           end or "ongoing",
        "description":   similar_history,
    }


def _what_happened_in_era(era: str) -> str:
    descriptions = {
        "ai_bull_market":    "Post-rate-hike recovery driven by AI/tech enthusiasm. SPY+30%+ from Oct 2023 lows.",
        "rate_hike_bear":    "Fed hiked 525bps in 16 months. SPY fell ~25%. Fastest tightening since 1980.",
        "covid_recovery":    "Zero-rate QE boom. SPY nearly doubled. Meme stocks, SPAC mania.",
        "covid_crash":       "Fastest 30% crash in history. Recovery equally fast (2 months).",
        "qe_bull_market":    "11-year bull market. Fed held rates near zero. SPY +400%.",
        "financial_crisis":  "Housing/bank collapse. SPY fell 57%. VIX hit 89. Lehman, TARP.",
        "housing_boom":      "Post-dot-com recovery. Housing bubble. SPY +100%. Low VIX.",
        "dotcom_crash":      "Nasdaq fell 78%. SPY -49%. 2.5 years of decline.",
        "great_bull_market": "18-year bull run. Deregulation, tech boom, globalization.",
        "stagflation":       "High inflation + stagnation. Two severe bear markets.",
        "great_depression":  "SPY/DJIA fell 89%. Deflation, mass unemployment.",
    }
    return descriptions.get(era, "Historical pattern data available in market_history DB.")
