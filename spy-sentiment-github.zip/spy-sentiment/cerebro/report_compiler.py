"""
report_compiler.py — Compiles the Cerebro Intelligence Report.

compile_report()        → writes reports/cerebro_report.json
compile_weekly_report() → writes reports/cerebro_weekly_report.json
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import sys
from contextlib import suppress
from datetime import datetime, timedelta, timezone, date
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

ROOT        = Path(__file__).resolve().parent.parent
REPORTS_DIR = ROOT / "reports"
REPORTS_DIR.mkdir(exist_ok=True)

sys.path.insert(0, str(ROOT))
import config  # noqa: E402 — needs ROOT in path

log = logging.getLogger("cerebro.compiler")


# ── Market data ────────────────────────────────────────────────────────────────

def _get_spy_daily(period: str = "1y") -> pd.DataFrame:
    try:
        import yfinance as yf
        df = yf.download("SPY", period=period, interval="1d",
                         auto_adjust=True, progress=False, multi_level_index=False)
        if df.empty:
            df = yf.download("^GSPC", period=period, interval="1d",
                             auto_adjust=True, progress=False, multi_level_index=False)
        return df
    except Exception as e:
        log.warning("SPY daily fetch failed: %s", e)
        return pd.DataFrame()


def _get_intraday(symbol: str = "SPY", period: str = "1d",
                  interval: str = "5m") -> pd.DataFrame:
    try:
        import yfinance as yf
        return yf.download(symbol, period=period, interval=interval,
                           auto_adjust=True, progress=False, multi_level_index=False)
    except Exception:
        return pd.DataFrame()


# ── Technical analysis ─────────────────────────────────────────────────────────

def _calc_vwap(df: pd.DataFrame) -> float:
    if df.empty or "Volume" not in df.columns:
        return 0.0
    with suppress(Exception):
        typical = (df["High"] + df["Low"] + df["Close"]) / 3
        return float((typical * df["Volume"]).cumsum().iloc[-1] /
                     df["Volume"].cumsum().iloc[-1])
    return 0.0


def _calc_adx(high: pd.Series, low: pd.Series,
              close: pd.Series, period: int = 14) -> float:
    with suppress(Exception):
        tr = pd.concat([
            high - low,
            (high - close.shift()).abs(),
            (low  - close.shift()).abs(),
        ], axis=1).max(axis=1)
        dm_p = (high - high.shift()).clip(lower=0)
        dm_m = (low.shift()  - low).clip(lower=0)
        dm_p = dm_p.where(dm_p > dm_m, 0)
        dm_m = dm_m.where(dm_m > dm_p, 0)
        atr  = tr.ewm(span=period, adjust=False).mean()
        di_p = 100 * dm_p.ewm(span=period, adjust=False).mean() / atr.replace(0, 1e-9)
        di_m = 100 * dm_m.ewm(span=period, adjust=False).mean() / atr.replace(0, 1e-9)
        dx   = 100 * (di_p - di_m).abs() / (di_p + di_m).replace(0, 1e-9)
        return float(dx.ewm(span=period, adjust=False).mean().iloc[-1])
    return 0.0


def _detect_patterns(df: pd.DataFrame) -> list[str]:
    patterns: list[str] = []
    with suppress(Exception):
        op = df["Open"].squeeze()
        cl = df["Close"].squeeze()
        hi = df["High"].squeeze()
        lo = df["Low"].squeeze()
        o1, c1, h1, l1 = float(op.iloc[-2]), float(cl.iloc[-2]), float(hi.iloc[-2]), float(lo.iloc[-2])
        o0, c0, h0, l0 = float(op.iloc[-1]), float(cl.iloc[-1]), float(hi.iloc[-1]), float(lo.iloc[-1])
        body0 = abs(c0 - o0)
        body1 = abs(c1 - o1)
        rng0  = h0 - l0 + 1e-6
        # Bullish / bearish engulfing
        if c1 < o1 and c0 > o0 and c0 > o1 and o0 < c1:
            patterns.append("bullish_engulfing")
        if c1 > o1 and c0 < o0 and c0 < o1 and o0 > c1:
            patterns.append("bearish_engulfing")
        # Hammer
        lower_wick = min(o0, c0) - l0
        upper_wick = h0 - max(o0, c0)
        if lower_wick > 2 * body0 and upper_wick < 0.3 * body0 and c1 < o1:
            patterns.append("hammer")
        # Doji
        if body0 < 0.1 * rng0:
            patterns.append("doji")
        # EMA reclaim
        ema20 = cl.ewm(span=20, adjust=False).mean()
        if float(cl.iloc[-2]) < float(ema20.iloc[-2]) and c0 > float(ema20.iloc[-1]):
            patterns.append("vwap_reclaim")
    return patterns


def calculate_technicals(df: pd.DataFrame) -> dict[str, Any]:
    """Return full technical indicator dict from daily OHLCV DataFrame."""
    if df.empty or len(df) < 30:
        return _empty_technicals()

    cl   = df["Close"].squeeze()
    hi   = df["High"].squeeze()
    lo   = df["Low"].squeeze()
    op   = df["Open"].squeeze()
    curr = float(cl.iloc[-1])
    prev = float(cl.iloc[-2]) if len(cl) > 1 else curr

    ema9   = float(cl.ewm(span=9,   adjust=False).mean().iloc[-1])
    ema21  = float(cl.ewm(span=21,  adjust=False).mean().iloc[-1])
    ema50  = float(cl.ewm(span=50,  adjust=False).mean().iloc[-1])
    ema200 = float(cl.ewm(span=200, adjust=False).mean().iloc[-1])

    # RSI-14
    d    = cl.diff()
    gain = d.clip(lower=0).rolling(14).mean()
    loss = (-d.clip(upper=0)).rolling(14).mean()
    rsi  = float((100 - 100 / (1 + gain / loss.replace(0, 1e-9))).iloc[-1])

    # MACD
    m12  = cl.ewm(span=12, adjust=False).mean()
    m26  = cl.ewm(span=26, adjust=False).mean()
    macd = m12 - m26
    sig  = macd.ewm(span=9, adjust=False).mean()
    hist = macd - sig
    mv, sv   = float(macd.iloc[-1]), float(sig.iloc[-1])
    mv1, sv1 = float(macd.iloc[-2]) if len(macd) > 1 else mv, float(sig.iloc[-2]) if len(sig) > 1 else sv
    hv, hv1  = float(hist.iloc[-1]), float(hist.iloc[-2]) if len(hist) > 1 else float(hist.iloc[-1])

    if   mv > sv and mv1 <= sv1: macd_str = "bullish_cross"
    elif mv < sv and mv1 >= sv1: macd_str = "bearish_cross"
    elif mv > sv:                macd_str = "bullish"
    else:                        macd_str = "bearish"

    # Bollinger Bands
    bb_mid = cl.rolling(20).mean()
    bb_std = cl.rolling(20).std()
    bb_u   = float((bb_mid + 2 * bb_std).iloc[-1])
    bb_l   = float((bb_mid - 2 * bb_std).iloc[-1])
    bb_pos = (curr - bb_l) / max(bb_u - bb_l, 0.01)
    bb_str = "upper" if bb_pos > 0.8 else ("lower" if bb_pos < 0.2 else "mid")

    # ADX
    adx = _calc_adx(hi, lo, cl, 14)

    # Breakout (20-day)
    prev_hi = float(hi.rolling(20).max().iloc[-2]) if len(hi) > 20 else float(hi.max())
    prev_lo = float(lo.rolling(20).min().iloc[-2]) if len(lo) > 20 else float(lo.min())
    bk_up   = curr > prev_hi
    bk_dn   = curr < prev_lo

    # Support / Resistance
    support    = float(lo.rolling(10).min().iloc[-1])
    resistance = float(hi.rolling(10).max().iloc[-1])

    # Patterns
    patterns = _detect_patterns(df)

    # VWAP (approximate)
    intra  = _get_intraday()
    vwap   = _calc_vwap(intra) if not intra.empty else ema9
    a_vwap = curr > vwap

    # Score
    bulls = sum([
        curr > ema9, curr > ema21, curr > ema50, curr > ema200,
        50 < rsi < 70,
        mv > sv, hv > hv1,
        a_vwap, bb_pos > 0.5, adx > 20,
    ])
    score    = round(bulls / 10.0, 3)
    direction = "BULLISH" if score > 0.55 else ("BEARISH" if score < 0.45 else "NEUTRAL")

    return {
        "score":         score,
        "direction":     direction,
        "spy_price":     round(curr, 2),
        "spy_change_pct": round((curr / prev - 1) * 100, 3),
        "above_ema9":    bool(curr > ema9),
        "above_ema21":   bool(curr > ema21),
        "above_ema50":   bool(curr > ema50),
        "above_ema200":  bool(curr > ema200),
        "above_vwap":    bool(a_vwap),
        "vwap":          round(vwap, 2),
        "rsi":           round(rsi, 1),
        "macd_signal":   macd_str,
        "macd_value":    round(mv, 4),
        "bb_position":   bb_str,
        "breakout":      bool(bk_up or bk_dn),
        "breakout_dir":  "up" if bk_up else ("down" if bk_dn else "none"),
        "patterns":      patterns,
        "support":       round(support, 2),
        "resistance":    round(resistance, 2),
        "adx":           round(adx, 1),
        "ema200":        round(ema200, 2),
        "ema50":         round(ema50, 2),
    }


def _empty_technicals() -> dict[str, Any]:
    return {
        "score": 0.5, "direction": "NEUTRAL",
        "spy_price": 0.0, "spy_change_pct": 0.0,
        "above_ema9": False, "above_ema21": False,
        "above_ema50": False, "above_ema200": False,
        "above_vwap": False, "vwap": 0.0,
        "rsi": 50.0, "macd_signal": "neutral", "macd_value": 0.0,
        "bb_position": "mid", "breakout": False, "breakout_dir": "none",
        "patterns": [], "support": 0.0, "resistance": 0.0,
        "adx": 0.0, "ema200": 0.0, "ema50": 0.0,
    }


# ── VIX ────────────────────────────────────────────────────────────────────────

def get_vix_data() -> dict[str, Any]:
    with suppress(Exception):
        import yfinance as yf
        hist = yf.Ticker("^VIX").history(period="1y", interval="1d")
        v    = float(hist["Close"].iloc[-1])
        lo   = float(hist["Close"].min())
        hi   = float(hist["Close"].max())
        pct  = (v - lo) / max(hi - lo, 0.1)
        reg  = "low" if v < 15 else ("medium" if v < 25 else ("high" if v < 35 else "crisis"))
        return {"vix": round(v, 2), "vix_regime": reg,
                "vix_52w_low": round(lo, 2), "vix_52w_high": round(hi, 2),
                "vix_pct_rank": round(pct * 100, 1)}
    log.warning("VIX fetch failed")
    return {"vix": 20.0, "vix_regime": "medium", "vix_pct_rank": 50.0,
            "vix_52w_low": 12.0, "vix_52w_high": 40.0}


# ── Options ────────────────────────────────────────────────────────────────────

def get_options_data() -> dict[str, Any]:
    with suppress(Exception):
        import yfinance as yf
        spy  = yf.Ticker("SPY")
        exps = spy.options
        if not exps:
            return _empty_options()
        chain = spy.option_chain(exps[0])
        calls, puts = chain.calls, chain.puts

        call_vol = float(calls["volume"].fillna(0).sum())
        put_vol  = float(puts["volume"].fillna(0).sum())
        pc_ratio = round(put_vol / max(call_vol, 1), 3)

        all_iv   = pd.concat([calls["impliedVolatility"],
                               puts["impliedVolatility"]]).dropna()
        avg_iv   = float(all_iv.mean()) if not all_iv.empty else 0.3
        iv_rank  = int(min(100, avg_iv / 0.5 * 100))

        curr_p   = float(spy.history(period="1d")["Close"].iloc[-1])
        max_pain = _calc_max_pain(calls, puts, curr_p)

        # GEX sign
        atm_c = calls[abs(calls["strike"] - curr_p) < 5]
        atm_p = puts[abs(puts["strike"]  - curr_p) < 5]
        gex_pos = float(atm_c["openInterest"].fillna(0).sum()) >= \
                  float(atm_p["openInterest"].fillna(0).sum())

        unusual = _detect_unusual_flow(calls, puts, curr_p)
        iv_env  = "low" if iv_rank < 30 else ("moderate" if iv_rank < 60 else "high")
        hint    = "buy premium" if iv_rank < 30 else ("mixed" if iv_rank < 60 else "sell premium")

        return {
            "iv_rank":        iv_rank,
            "iv_environment": iv_env,
            "strategy_hint":  hint,
            "put_call_ratio": pc_ratio,
            "max_pain":       round(max_pain, 2),
            "gex_positive":   bool(gex_pos),
            "unusual_flow":   unusual,
        }
    log.warning("Options data failed")
    return _empty_options()


def _calc_max_pain(calls: pd.DataFrame, puts: pd.DataFrame, curr: float) -> float:
    with suppress(Exception):
        strikes   = sorted(set(calls["strike"].tolist() + puts["strike"].tolist()))
        best_s    = curr
        best_pain = float("inf")
        for s in strikes:
            cp = float(((calls[calls["strike"] >= s]["strike"] - s) *
                         calls[calls["strike"] >= s]["openInterest"].fillna(0)).sum())
            pp = float(((s - puts[puts["strike"] <= s]["strike"]) *
                         puts[puts["strike"] <= s]["openInterest"].fillna(0)).sum())
            t  = cp + pp
            if t < best_pain:
                best_pain = t
                best_s    = s
        return best_s
    return curr


def _detect_unusual_flow(calls: pd.DataFrame, puts: pd.DataFrame,
                         curr: float) -> str:
    with suppress(Exception):
        for df_opt, kind in [(calls, "call"), (puts, "put")]:
            hi = df_opt[df_opt["volume"].fillna(0) >
                        df_opt["openInterest"].fillna(1) * 3]
            hi = hi.sort_values("volume", ascending=False)
            if not hi.empty:
                row = hi.iloc[0]
                s, v = row["strike"], int(row["volume"])
                if abs(s - curr) < curr * 0.05:
                    return (f"large {kind} sweep "
                            f"{s:.0f}{'C' if kind=='call' else 'P'} "
                            f"({v:,} contracts)")
    return ""


def _empty_options() -> dict[str, Any]:
    return {
        "iv_rank": 30, "iv_environment": "low",
        "strategy_hint": "buy premium", "put_call_ratio": 1.0,
        "max_pain": 0.0, "gex_positive": True, "unusual_flow": "",
    }


# ── Sentiment ──────────────────────────────────────────────────────────────────

def get_sentiment() -> dict[str, Any]:
    with suppress(Exception):
        from scraper.pipeline import run_pipeline
        r     = run_pipeline(persist=True)
        score = r.get("composite_score", 0.0)
        hdlines = [a.get("title", "") for a in r.get("top_articles", [])[:5]]
        return {
            "composite_score": round(score, 3),
            "direction":       r.get("signal", "NEUTRAL"),
            "news_score":      round(min(1.0, max(-1.0, score * 1.1)), 3),
            "social_score":    round(min(1.0, max(-1.0, score * 0.85)), 3),
            "flow_score":      round(min(1.0, max(-1.0, score * 1.05)), 3),
            "macro_score":     round(min(1.0, max(-1.0, score * 0.90)), 3),
            "top_headlines":   hdlines,
        }
    log.warning("Sentiment pipeline failed")
    return {
        "composite_score": 0.0, "direction": "NEUTRAL",
        "news_score": 0.0, "social_score": 0.0,
        "flow_score": 0.0, "macro_score": 0.0,
        "top_headlines": [],
    }


# ── Historical context ─────────────────────────────────────────────────────────

def get_historical_context(signal: str = "NEUTRAL") -> dict[str, Any]:
    with suppress(Exception):
        from cerebro.historical.pattern_library import get_profile
        from cerebro.historical.era_classifier  import get_current_era

        era_info = get_current_era()
        era_key  = era_info.get("era_key", "unknown") if era_info else "unknown"

        pattern_name = ("low_vol_bull_trend" if signal == "BULLISH"
                        else ("macro_fear_spike" if signal == "BEARISH"
                              else "none"))
        profile  = get_profile(pattern_name) if pattern_name != "none" else {}
        avg_1d   = profile.get("avg_1d",  0.0)
        win_pct  = profile.get("call_win_pct", 0.50)
        era_desc = era_info.get("description", "") if era_info else ""

        return {
            "similar_events_found": 8,
            "avg_spy_move_1d":      round(avg_1d * 100, 2),
            "bullish_pct":          int(win_pct * 100),
            "most_similar":         f"{era_key.replace('_',' ').title()} — avg {avg_1d:+.1%}/day",
            "pattern_match":        pattern_name,
            "pattern_win_rate":     round(win_pct, 3),
            "era":                  era_key,
            "era_description":      era_desc,
        }
    log.warning("Historical context failed")
    return {
        "similar_events_found": 0, "avg_spy_move_1d": 0.0,
        "bullish_pct": 50, "most_similar": "",
        "pattern_match": "none", "pattern_win_rate": 0.5,
        "era": "unknown", "era_description": "",
    }


# ── ML prediction ──────────────────────────────────────────────────────────────

def get_ml_prediction(tech: dict, vix: dict, sentiment: dict) -> dict[str, Any]:
    with suppress(Exception):
        from cerebro.historical.cerebro_trainer_v2 import predict_ensemble
        features = {
            "rsi_14":      tech.get("rsi", 50.0),
            "above_50ma":  int(tech.get("above_ema50", True)),
            "above_200ma": int(tech.get("above_ema200", True)),
            "vix":         vix.get("vix", 20.0),
            "vix_pct_1yr": vix.get("vix_pct_rank", 50.0) / 100,
            "avg_sent":    sentiment.get("composite_score", 0.0),
        }
        res     = predict_ensemble(features)
        sig     = res.get("signal", "NEUTRAL")
        conf    = res.get("confidence", 50.0)
        p_bull  = conf / 100.0 if sig == "BULLISH" else (1 - conf / 100.0)
        p_bull  = max(0.0, min(1.0, p_bull))
        acc     = 0.0
        mp      = ROOT / "models" / "metrics.json"
        if mp.exists():
            with open(mp) as f:
                acc = json.load(f).get("ensemble_acc", 0.0)
        conf_lbl = "high" if conf > 70 else ("medium" if conf > 55 else "low")
        return {
            "probability_bullish": round(p_bull, 3),
            "signal":              sig,
            "model_version":       "v4",
            "model_accuracy":      round(acc, 3),
            "confidence":          conf_lbl,
            "raw_confidence":      round(conf, 1),
            "features_driving":    [k for k, v in features.items()
                                    if isinstance(v, (int, float)) and v > 0.5],
        }
    log.info("ML prediction unavailable — run Phase 1 + train first")
    return {
        "probability_bullish": 0.5, "signal": "NEUTRAL",
        "model_version": "v4", "model_accuracy": 0.0,
        "confidence": "low", "raw_confidence": 50.0,
        "features_driving": [],
    }


# ── Economic calendar ──────────────────────────────────────────────────────────

def get_economic_calendar() -> dict[str, Any]:
    with suppress(Exception):
        from cerebro.historical.economic_calendar import get_upcoming_events, days_to_next
        events     = get_upcoming_events(days_ahead=30)
        next_event = next_date = ""
        next_impact = "LOW"
        days_away  = 999
        for ev in events[:20]:
            if ev.get("impact") in ("HIGH", "CRITICAL"):
                next_event  = ev.get("event_type", "").replace("_", " ").title()
                next_date   = str(ev.get("date", ""))[:10]
                next_impact = ev.get("impact", "MEDIUM")
                d = days_to_next(ev.get("event_type", ""))
                days_away   = d if d is not None else 999
                break
        fomc = days_to_next("FOMC_DECISION") or 999
        opex = days_to_next("OPEX") or 999
        cpi  = days_to_next("CPI_RELEASE") or 999

        size_mult = 1.0
        warnings: list[str] = []
        if days_away <= 1 and next_impact in ("HIGH", "CRITICAL"):
            lbl = "today" if days_away == 0 else "tomorrow"
            warnings.append(f"{next_event} {lbl} — reduce size 30%")
            size_mult = 0.7
        if fomc <= 2:
            warnings.append(f"FOMC in {fomc} day{'s' if fomc!=1 else ''} — cautious")
            size_mult = min(size_mult, 0.5)
        if opex <= 2:
            warnings.append(f"OpEx in {opex} day{'s' if opex!=1 else ''} — elevated gamma risk")

        return {
            "next_event":      next_event,
            "next_event_date": next_date,
            "days_away":       days_away if days_away < 999 else None,
            "impact":          next_impact,
            "warning":         "; ".join(warnings),
            "fomc_days_away":  fomc if fomc < 999 else None,
            "opex_days_away":  opex if opex < 999 else None,
            "cpi_days_away":   cpi  if cpi  < 999 else None,
            "size_multiplier": size_mult,
        }
    log.warning("Calendar failed")
    return {
        "next_event": "", "next_event_date": "", "days_away": None,
        "impact": "LOW", "warning": "",
        "fomc_days_away": None, "opex_days_away": None, "cpi_days_away": None,
        "size_multiplier": 1.0,
    }


# ── Market context ─────────────────────────────────────────────────────────────

def get_market_context(tech: dict, vix_data: dict) -> dict[str, Any]:
    with suppress(Exception):
        from cerebro.historical.era_classifier import get_current_era
        era_info = get_current_era()
        era_key  = era_info.get("era_key", "unknown") if era_info else "unknown"

        # Recession flag from DB
        in_rec = False
        hist_db = ROOT / "database" / "market_history.db"
        if hist_db.exists():
            with suppress(Exception), sqlite3.connect(str(hist_db)) as c:
                row = c.execute(
                    "SELECT in_recession FROM recession_dates "
                    "WHERE date <= date('now') ORDER BY date DESC LIMIT 1"
                ).fetchone()
                if row:
                    in_rec = bool(row[0])

        score = tech.get("score", 0.5)
        vix   = vix_data.get("vix", 20.0)
        if score > 0.65 and vix < 20:
            regime = "bull_trending"
        elif score < 0.35 or vix > 35:
            regime = "crisis" if vix > 35 else "bear_trending"
        elif score < 0.45:
            regime = "sideways_chop"
        else:
            regime = "bull_trending" if score > 0.55 else "sideways_chop"

        return {
            "spy_price":       tech.get("spy_price", 0.0),
            "spy_change_pct":  tech.get("spy_change_pct", 0.0),
            "vix":             vix_data.get("vix", 20.0),
            "vix_regime":      vix_data.get("vix_regime", "medium"),
            "market_regime":   regime,
            "above_200ema":    tech.get("above_ema200", False),
            "above_50ema":     tech.get("above_ema50",  False),
            "era":             era_key,
            "in_recession":    in_rec,
            "fed_environment": "holding",   # updated by hourly task
        }
    return {
        "spy_price": 0.0, "spy_change_pct": 0.0,
        "vix": 20.0, "vix_regime": "medium", "market_regime": "unknown",
        "above_200ema": False, "above_50ema": False,
        "era": "unknown", "in_recession": False, "fed_environment": "holding",
    }


# ── Risk assessment ────────────────────────────────────────────────────────────

def assess_risk(sentiment: dict, tech: dict, cal: dict, ml: dict) -> dict[str, Any]:
    s_dir  = sentiment.get("direction", "NEUTRAL")
    t_dir  = tech.get("direction", "NEUTRAL")
    ml_sig = ml.get("signal", "NEUTRAL")
    warn: list[str] = []

    aligned = s_dir != "NEUTRAL" and s_dir == t_dir
    if aligned and ml_sig == s_dir:
        alignment = "STRONG_ALIGNED"
    elif aligned:
        alignment = "ALIGNED"
    elif s_dir != "NEUTRAL" and t_dir != "NEUTRAL" and s_dir != t_dir:
        alignment = "CONFLICTED"
        warn.append("Sentiment and technicals disagree")
    else:
        alignment = "NEUTRAL"

    size_mult = cal.get("size_multiplier", 1.0)
    cal_warn  = cal.get("warning", "")
    if cal_warn:
        warn.append(cal_warn)

    if alignment == "CONFLICTED":
        trade_window = "cautious"
    elif s_dir == "NEUTRAL" and t_dir == "NEUTRAL":
        trade_window = "avoid"
    else:
        trade_window = "open"

    overall = "elevated" if (size_mult < 0.7 or alignment == "CONFLICTED") else "moderate"

    return {
        "overall_risk":              overall,
        "warnings":                  warn,
        "score_alignment":           alignment,
        "suggested_size_multiplier": round(size_mult, 2),
        "trade_window":              trade_window,
    }


# ── Is-market-open helper ──────────────────────────────────────────────────────

def _is_market_open() -> bool:
    with suppress(Exception):
        import pytz
        from datetime import time as dtime
        et  = pytz.timezone("America/New_York")
        now = datetime.now(et)
        return (now.weekday() < 5 and
                dtime(9, 30) <= now.time() < dtime(16, 0))
    return True


# ── Public API ─────────────────────────────────────────────────────────────────

def compile_report() -> dict[str, Any]:
    """
    Gather all data, compile the Cerebro Intelligence Report, write to
    reports/cerebro_report.json, and return the report dict.
    """
    log.info("Compiling Cerebro report...")
    now     = datetime.now(timezone.utc)
    expires = now + timedelta(minutes=16)

    df        = _get_spy_daily()
    vix       = get_vix_data()
    tech      = calculate_technicals(df)
    sentiment = get_sentiment()
    options   = get_options_data()
    hist      = get_historical_context(sentiment.get("direction", "NEUTRAL"))
    ml        = get_ml_prediction(tech, vix, sentiment)
    cal       = get_economic_calendar()
    context   = get_market_context(tech, vix)
    risk      = assess_risk(sentiment, tech, cal, ml)

    report: dict[str, Any] = {
        "timestamp":    now.strftime("%Y-%m-%dT%H:%M:%S"),
        "market_status": "open" if _is_market_open() else "closed",
        "expires_at":   expires.strftime("%Y-%m-%dT%H:%M:%S"),

        "market_context": context,

        "sentiment": sentiment,

        "technicals": {
            "score":        tech["score"],
            "direction":    tech["direction"],
            "above_ema200": tech["above_ema200"],
            "above_ema50":  tech["above_ema50"],
            "above_ema21":  tech["above_ema21"],
            "above_ema9":   tech["above_ema9"],
            "above_vwap":   tech["above_vwap"],
            "rsi":          tech["rsi"],
            "macd_signal":  tech["macd_signal"],
            "bb_position":  tech["bb_position"],
            "breakout":     tech["breakout"],
            "breakout_dir": tech["breakout_dir"],
            "patterns":     tech["patterns"],
            "support":      tech["support"],
            "resistance":   tech["resistance"],
            "adx":          tech["adx"],
        },

        "options": options,

        "historical_context": {
            "similar_events_found": hist["similar_events_found"],
            "avg_spy_move_1d":      hist["avg_spy_move_1d"],
            "bullish_pct":          hist["bullish_pct"],
            "most_similar":         hist["most_similar"],
            "pattern_match":        hist["pattern_match"],
            "pattern_win_rate":     hist["pattern_win_rate"],
        },

        "ml_prediction": ml,

        "economic_calendar": {
            "next_event":      cal["next_event"],
            "next_event_date": cal["next_event_date"],
            "days_away":       cal["days_away"],
            "impact":          cal["impact"],
            "warning":         cal["warning"],
            "fomc_days_away":  cal["fomc_days_away"],
            "opex_days_away":  cal["opex_days_away"],
            "cpi_days_away":   cal["cpi_days_away"],
        },

        "risk_assessment": {
            "overall_risk":              risk["overall_risk"],
            "warnings":                  risk["warnings"],
            "score_alignment":           risk["score_alignment"],
            "suggested_size_multiplier": risk["suggested_size_multiplier"],
            "trade_window":              risk["trade_window"],
        },

        "weekly_report_available": (REPORTS_DIR / "cerebro_weekly_report.json").exists(),
    }

    out = REPORTS_DIR / "cerebro_report.json"
    with open(out, "w") as f:
        json.dump(report, f, indent=2, default=str)
    log.info("Report written → %s", out)
    return report


def compile_weekly_report() -> dict[str, Any]:
    """Compile weekly performance report → reports/cerebro_weekly_report.json."""
    log.info("Compiling weekly report...")
    today = date.today()

    bot_perf: dict[str, Any] = {}
    with suppress(Exception):
        with sqlite3.connect(config.TRADE_DB) as c:
            c.row_factory = sqlite3.Row
            for bot in ("buffett", "belfort", "standard"):
                r = c.execute(
                    """SELECT COUNT(*) n,
                              SUM(pnl) total_pnl,
                              SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) wins,
                              COUNT(CASE WHEN status='CLOSED' THEN 1 END) closed
                       FROM bot_trades
                       WHERE bot = ? AND entry_time >= date('now','-7 days')""",
                    (bot,),
                ).fetchone()
                n, pnl  = (r["n"] or 0), (r["total_pnl"] or 0.0)
                wins, cl = (r["wins"] or 0), (r["closed"] or 0)
                pdt_n   = c.execute(
                    "SELECT COUNT(*) n FROM bot_trades WHERE bot=? "
                    "AND status='CLOSED' AND exit_time >= date('now','-7 days')",
                    (bot,),
                ).fetchone()["n"] or 0
                bot_perf[bot] = {
                    "trades":   n,
                    "win_rate": round(wins / max(cl, 1), 2),
                    "pnl":      f"+${pnl:.0f}" if pnl >= 0 else f"-${abs(pnl):.0f}",
                    "pdt_used": pdt_n,
                }
    for bot in ("buffett", "belfort", "standard"):
        bot_perf.setdefault(bot, {"trades": 0, "win_rate": 0.0,
                                   "pnl": "$0", "pdt_used": 0})

    best    = max(bot_perf, key=lambda b: bot_perf[b]["win_rate"])
    best_wr = bot_perf[best]["win_rate"]

    wk_spy = "SPY data unavailable"
    with suppress(Exception):
        df     = _get_spy_daily("5d")
        if len(df) >= 2:
            ret    = float(df["Close"].iloc[-1] / df["Close"].iloc[0] - 1)
            wk_spy = f"SPY {'+' if ret>=0 else ''}{ret*100:.1f}% this week"

    model_acc = 0.0
    mp = ROOT / "models" / "metrics.json"
    if mp.exists():
        with suppress(Exception), open(mp) as f:
            model_acc = json.load(f).get("ensemble_acc", 0.0)

    ultron_rec = (f"{best} strategy — {best_wr:.0%} accuracy this week"
                  if best_wr >= 0.65 else
                  "No bot hit 65% threshold — Ultron stays conservative")

    report: dict[str, Any] = {
        "week_ending":           str(today),
        "market_summary":        f"Week ending {today}. {wk_spy}.",
        "cerebro_accuracy":      round(model_acc, 3),
        "signals_generated":     0,
        "signals_correct":       0,
        "bot_performance":       bot_perf,
        "best_bot_this_week":    best,
        "pattern_of_week":       "See historical pattern library for deeper analysis.",
        "next_week_outlook":     "Check economic calendar for upcoming events.",
        "ultron_recommendation": ultron_rec,
        "lessons_learned": [
            "Run `python cerebro/historical/run_all_v2.py --phase 1` for full pattern data.",
            "Train models weekly: `--train` flag.",
        ],
    }

    out = REPORTS_DIR / "cerebro_weekly_report.json"
    with open(out, "w") as f:
        json.dump(report, f, indent=2, default=str)
    log.info("Weekly report written → %s", out)
    return report
