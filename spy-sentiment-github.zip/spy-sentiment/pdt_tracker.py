"""
pdt_tracker.py — Pattern Day Trader rule enforcement.

A "day trade" is an opening trade and a closing trade on the same
calendar day for the same instrument.  FINRA allows at most 3 day
trades in any rolling 5-business-day window for accounts under $25k.

Schema (pdt_log table in PDT_DB):
  id          INTEGER PK
  trade_id    TEXT    (caller-supplied unique ID, e.g. UUID)
  direction   TEXT    ("BUY" | "SELL")
  action      TEXT    ("OPEN" | "CLOSE")
  timestamp   TEXT    (ISO-8601 UTC)
"""

from __future__ import annotations

import sqlite3
import logging
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta
from typing import Generator

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

log = logging.getLogger(__name__)


# ── DB helpers ────────────────────────────────────────────────────────────────

@contextmanager
def _conn() -> Generator[sqlite3.Connection, None, None]:
    c = sqlite3.connect(config.PDT_DB)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def _init() -> None:
    with _conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS pdt_log (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                trade_id  TEXT NOT NULL,
                direction TEXT NOT NULL,
                action    TEXT NOT NULL,
                timestamp TEXT NOT NULL
            )
        """)
        c.execute("CREATE INDEX IF NOT EXISTS idx_pdt_ts ON pdt_log(timestamp)")


# ── public API ────────────────────────────────────────────────────────────────

def log_trade(trade_id: str, direction: str, action: str,
              timestamp: datetime | None = None) -> None:
    """
    Record a trade leg.

    Parameters
    ----------
    trade_id  : unique identifier (same for OPEN and CLOSE of a round-trip)
    direction : "BUY" or "SELL"
    action    : "OPEN" or "CLOSE"
    timestamp : UTC datetime (defaults to now)
    """
    _init()
    ts = (timestamp or datetime.now(timezone.utc)).isoformat()
    with _conn() as c:
        c.execute(
            "INSERT INTO pdt_log (trade_id, direction, action, timestamp) VALUES (?,?,?,?)",
            (trade_id, direction.upper(), action.upper(), ts),
        )
    log.debug("PDT log: trade_id=%s dir=%s action=%s ts=%s", trade_id, direction, action, ts)


def _business_days_ago(n: int) -> datetime:
    """Return a UTC datetime roughly n business days in the past."""
    dt = datetime.now(timezone.utc)
    days_back = 0
    while days_back < n:
        dt -= timedelta(days=1)
        if dt.weekday() < 5:   # Mon-Fri
            days_back += 1
    return dt


def count_day_trades(lookback_days: int = 5) -> int:
    """
    Count same-day OPEN+CLOSE pairs (day trades) in the last `lookback_days`
    business days.
    """
    _init()
    cutoff = _business_days_ago(lookback_days).isoformat()

    with _conn() as c:
        rows = c.execute(
            "SELECT trade_id, action, timestamp FROM pdt_log WHERE timestamp >= ? ORDER BY timestamp",
            (cutoff,),
        ).fetchall()

    # Find trade_ids that have both an OPEN and a CLOSE on the same calendar date
    opens:  dict[str, str] = {}   # trade_id → date of OPEN
    closes: dict[str, str] = {}   # trade_id → date of CLOSE
    for row in rows:
        date_str = row["timestamp"][:10]   # YYYY-MM-DD
        if row["action"] == "OPEN":
            opens[row["trade_id"]] = date_str
        elif row["action"] == "CLOSE":
            closes[row["trade_id"]] = date_str

    day_trades = sum(
        1 for tid, open_date in opens.items()
        if closes.get(tid) == open_date
    )
    return day_trades


def is_pdt_blocked() -> bool:
    """Return True if the account has used all PDT day-trade allowances."""
    return count_day_trades() >= config.PDT_MAX_DAY_TRADES


def get_pdt_status() -> dict:
    """
    Return a full PDT status snapshot.

    Keys: day_trades_used, day_trades_remaining, blocked, resets_on (date str)
    """
    _init()
    used      = count_day_trades(config.PDT_WINDOW_DAYS)
    remaining = max(config.PDT_MAX_DAY_TRADES - used, 0)
    blocked   = used >= config.PDT_MAX_DAY_TRADES

    # "resets on" = the next business day after the oldest day-trade in window
    cutoff = _business_days_ago(config.PDT_WINDOW_DAYS).isoformat()
    with _conn() as c:
        oldest = c.execute(
            "SELECT MIN(timestamp) as ts FROM pdt_log WHERE timestamp >= ? AND action='OPEN'",
            (cutoff,),
        ).fetchone()

    if oldest and oldest["ts"]:
        oldest_dt = datetime.fromisoformat(oldest["ts"])
        # advance one business day past the oldest open
        reset_dt = oldest_dt + timedelta(days=1)
        while reset_dt.weekday() >= 5:
            reset_dt += timedelta(days=1)
        resets_on = reset_dt.strftime("%a %b %d")
    else:
        resets_on = "N/A"

    return {
        "day_trades_used":      used,
        "day_trades_remaining": remaining,
        "blocked":              blocked,
        "resets_on":            resets_on,
    }
