# ── API Keys ──────────────────────────────────────────────────────────────────
NEWSAPI_KEY = "YOUR_NEWSAPI_KEY_HERE"   # https://newsapi.org/

# ── RSS Feeds ─────────────────────────────────────────────────────────────────
RSS_FEEDS = {
    "reuters":     "https://feeds.reuters.com/reuters/businessNews",
    "cnbc":        "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=100003114",
    "marketwatch": "https://feeds.marketwatch.com/marketwatch/topstories/",
    "yahoo_fin":   "https://finance.yahoo.com/news/rssindex",
    "seeking_alpha": "https://seekingalpha.com/market_currents.xml",
}

# ── SPY / Market Keywords ─────────────────────────────────────────────────────
SPY_KEYWORDS = [
    "SPY", "S&P 500", "S&P500", "stock market", "equities",
    "Federal Reserve", "Fed", "interest rate", "inflation", "CPI",
    "GDP", "recession", "bull market", "bear market", "volatility",
    "earnings", "Wall Street", "Dow Jones", "Nasdaq", "risk-off", "risk-on",
    "treasury", "yield curve", "FOMC", "Powell",
]

# ── Recency Decay (exponential half-life) ────────────────────────────────────
# Score weight = exp(-ln(2) / HALF_LIFE_HOURS * age_in_hours)
HALF_LIFE_HOURS = 4        # articles older than 4 h are half as impactful
MAX_ARTICLE_AGE_HOURS = 48 # discard articles older than this

# ── Composite Signal Thresholds ───────────────────────────────────────────────
SIGNAL_BULL_THRESHOLD  =  0.15   # weighted score above this → BULLISH
SIGNAL_BEAR_THRESHOLD  = -0.15   # weighted score below this → BEARISH
                                  # between the two          → NEUTRAL

# ── Pipeline ──────────────────────────────────────────────────────────────────
PIPELINE_INTERVAL_MINUTES = 15
NEWSAPI_PAGE_SIZE          = 50   # max articles per NewsAPI request
NEWSAPI_QUERY              = "SPY OR S&P 500 OR stock market OR Federal Reserve"

# ── Account / Risk Management ─────────────────────────────────────────────────
ACCOUNT_SIZE         = 2000    # total account equity ($)
BUYING_POWER         = 2000    # available buying power (margin account)
MAX_RISK_PER_TRADE   = 300     # max premium risked per trade (15% of account)
MAX_POSITION_SIZE    = 600     # max total open-position cost (30% of account)
STOP_LOSS_PCT        = 0.50    # exit at 50% loss of premium paid
PROFIT_TARGET_PCT    = 1.00    # exit at 100% gain (2x premium)

# ── PDT (Pattern Day Trader) Rule ────────────────────────────────────────────
PDT_MAX_DAY_TRADES   = 3       # max same-day round-trips per rolling window
PDT_WINDOW_DAYS      = 5       # rolling business-day window

# ── Console Warning Thresholds ────────────────────────────────────────────────
PDT_WARN_AT          = 2       # show RED warning when day trades used >= this
RISK_WARN_AT         = 200     # show RED warning when risk used ($) >= this

# ── Storage ───────────────────────────────────────────────────────────────────
import os as _os
import sys as _sys

# When running as a PyInstaller frozen exe, __file__ is inside the temp
# extraction dir (_MEIPASS).  Use the hardcoded project root instead so
# databases are written to a persistent location.
if getattr(_sys, 'frozen', False):
    _BASE = r"C:\spy-sentiment"
else:
    _BASE = _os.path.dirname(_os.path.abspath(__file__))

DB_PATH  = _os.path.join(_BASE, "spy_sentiment.db")
PDT_DB   = _os.path.join(_BASE, "pdt_log.db")
TRADE_DB = _os.path.join(_BASE, "trade_log.db")
