@echo off
call C:\spy-sentiment\build_app.bat > C:\spy-sentiment\build_output.txt 2>&1
