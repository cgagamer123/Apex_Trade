@echo off
setlocal
set PYTHON=C:\Users\funny\AppData\Local\Programs\Python\Python312\python.exe
set ROOT=%~dp0

echo.
echo  =========================================
echo   Cerebro Trading System -- First-Time Setup
echo  =========================================
echo.

echo [1/6] Installing Python dependencies...
"%PYTHON%" -m pip install ^
    flask transformers torch feedparser pandas schedule ^
    pystray pillow newsapi-python pyinstaller pywin32 ^
    fredapi lightgbm scikit-learn sentence-transformers faiss-cpu ^
    yfinance pandas-datareader lxml openpyxl tqdm requests ^
    --quiet
if errorlevel 1 ( echo ERROR: pip install failed & pause & exit /b 1 )
echo   Done.

echo [2/6] Generating icon assets...
"%PYTHON%" "%ROOT%assets\gen_icons.py"
if errorlevel 1 ( echo ERROR: icon generation failed & pause & exit /b 1 )
echo   Done.

echo [3/6] Initialising databases...
"%PYTHON%" -c "
import sys; sys.path.insert(0,'%ROOT:~0,-1%')
from storage.db import init_db; init_db()
from trade_logger import _init; _init()
from pdt_tracker import _init; _init()
print('  Databases initialised.')
"
if errorlevel 1 ( echo ERROR: DB init failed & pause & exit /b 1 )

echo [4/6] Building executable...
call "%ROOT%build_app.bat"
if errorlevel 1 ( echo ERROR: build failed & pause & exit /b 1 )

echo [5/6] Creating Desktop shortcut...
"%PYTHON%" "%ROOT%create_shortcut.py"

echo [6/6] Launching Cerebro...
start "" "%USERPROFILE%\Desktop\Cerebro Trading.exe"

echo.
echo  =========================================
echo   Setup complete! Cerebro is running.
echo   Dashboard: http://localhost:5000
echo  =========================================
echo.
pause
