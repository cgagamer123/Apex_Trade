"""
db.py — SQLite persistence for pipeline runs and article-level scores.

Schema
------
runs
  id               INTEGER PK
  run_at           TEXT    (ISO-8601 UTC)
  composite_score  REAL
  signal           TEXT
  article_count    INTEGER
  total_weight     REAL

articles
  id               INTEGER PK
  run_id           INTEGER FK → runs.id
  title            TEXT
  source           TEXT
  url              TEXT
  published_at     TEXT
  sentiment        TEXT
  sentiment_score  REAL
  decay_weight     REAL
"""

from __future__ import annotations

import logging
import sqlite3
from contextlib import contextmanager
from typing import Any, Generator

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

log = logging.getLogger(__name__)

# ── connection helper ─────────────────────────────────────────────────────────

@contextmanager
def _connect() -> Generator[sqlite3.Connection, None, None]:
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ── schema init ───────────────────────────────────────────────────────────────

def init_db() -> None:
    """Create tables if they don't exist."""
    with _connect() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS runs (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                run_at          TEXT    NOT NULL,
                composite_score REAL    NOT NULL,
                signal          TEXT    NOT NULL,
                article_count   INTEGER NOT NULL,
                total_weight    REAL    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS articles (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id          INTEGER NOT NULL REFERENCES runs(id),
                title           TEXT,
                source          TEXT,
                url             TEXT,
                published_at    TEXT,
                sentiment       TEXT,
                sentiment_score REAL,
                decay_weight    REAL
            );

            CREATE INDEX IF NOT EXISTS idx_runs_run_at ON runs(run_at);
            CREATE INDEX IF NOT EXISTS idx_articles_run_id ON articles(run_id);
        """)
    log.debug("DB initialised at %s", config.DB_PATH)


# ── write ─────────────────────────────────────────────────────────────────────

def save_run(result: dict[str, Any], articles: list[dict]) -> int:
    """Persist one pipeline result + its articles. Returns the run id."""
    init_db()
    with _connect() as conn:
        cur = conn.execute(
            """INSERT INTO runs
               (run_at, composite_score, signal, article_count, total_weight)
               VALUES (?, ?, ?, ?, ?)""",
            (
                result["run_at"],
                result["composite_score"],
                result["signal"],
                result["article_count"],
                result["total_weight"],
            ),
        )
        run_id = cur.lastrowid

        conn.executemany(
            """INSERT INTO articles
               (run_id, title, source, url, published_at,
                sentiment, sentiment_score, decay_weight)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            [
                (
                    run_id,
                    a.get("title"),
                    a.get("source"),
                    a.get("url"),
                    a["published_at"].isoformat()
                        if hasattr(a.get("published_at"), "isoformat")
                        else str(a.get("published_at")),
                    a.get("sentiment"),
                    a.get("sentiment_score"),
                    a.get("decay_weight"),
                )
                for a in articles
            ],
        )

    log.info("Saved run_id=%d with %d articles to DB.", run_id, len(articles))
    return run_id


# ── read ──────────────────────────────────────────────────────────────────────

def get_recent_runs(limit: int = 20) -> list[dict]:
    """Return the most recent `limit` pipeline runs."""
    init_db()
    with _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM runs ORDER BY run_at DESC LIMIT ?", (limit,)
        ).fetchall()
    return [dict(r) for r in rows]


def get_run_articles(run_id: int) -> list[dict]:
    """Return all articles for a specific run."""
    init_db()
    with _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM articles WHERE run_id = ?", (run_id,)
        ).fetchall()
    return [dict(r) for r in rows]


def get_signal_history(limit: int = 96) -> list[dict]:
    """Return (run_at, composite_score, signal) for the last `limit` runs."""
    init_db()
    with _connect() as conn:
        rows = conn.execute(
            """SELECT run_at, composite_score, signal
               FROM runs ORDER BY run_at DESC LIMIT ?""",
            (limit,),
        ).fetchall()
    return [dict(r) for r in rows]
