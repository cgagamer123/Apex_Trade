@echo off
setlocal
set PYTHON=C:\Users\funny\AppData\Local\Programs\Python\Python312\python.exe
set ROOT=%~dp0

echo.
echo  =========================================
echo   Cerebro Trading System -- App Builder
echo  =========================================
echo.

echo [1/4] Installing PyInstaller and packaging deps...
"%PYTHON%" -m pip install pyinstaller pystray pillow pywin32 --quiet
if errorlevel 1 ( echo ERROR: pip install failed & pause & exit /b 1 )

echo [2/4] Generating icon assets...
"%PYTHON%" "%ROOT%assets\gen_icons.py"
if errorlevel 1 ( echo ERROR: icon generation failed & pause & exit /b 1 )

echo [3/4] Running PyInstaller...
cd /d "%ROOT%"
"%PYTHON%" -m PyInstaller ^
    --onefile ^
    --windowed ^
    --icon="%ROOT%assets\icon.ico" ^
    --name="Cerebro Trading" ^
    --add-data "%ROOT%dashboard;dashboard" ^
    --add-data "%ROOT%assets;assets" ^
    --add-data "%ROOT%launcher;launcher" ^
    --add-data "%ROOT%scraper;scraper" ^
    --add-data "%ROOT%storage;storage" ^
    --add-data "%ROOT%cerebro;cerebro" ^
    --add-data "%ROOT%jarvis;jarvis" ^
    --hidden-import=pystray ^
    --hidden-import=PIL ^
    --hidden-import=PIL.Image ^
    --hidden-import=PIL.ImageDraw ^
    --hidden-import=flask ^
    --hidden-import=flask.templating ^
    --hidden-import=werkzeug ^
    --hidden-import=win32com.client ^
    --hidden-import=schedule ^
    --hidden-import=feedparser ^
    --hidden-import=pandas ^
    --hidden-import=numpy ^
    --hidden-import=transformers ^
    --hidden-import=torch ^
    --hidden-import=yfinance ^
    --hidden-import=pytz ^
    --hidden-import=scraper ^
    --hidden-import=scraper.pipeline ^
    --hidden-import=scraper.fetchers ^
    --hidden-import=scraper.processor ^
    --hidden-import=storage ^
    --hidden-import=storage.db ^
    --hidden-import=dashboard ^
    --hidden-import=dashboard.app ^
    --hidden-import=cerebro ^
    --hidden-import=cerebro.cerebro_engine ^
    --hidden-import=cerebro.report_compiler ^
    --hidden-import=cerebro.historical ^
    --hidden-import=cerebro.historical.era_classifier ^
    --hidden-import=cerebro.historical.pattern_library ^
    --hidden-import=cerebro.historical.economic_calendar ^
    --hidden-import=cerebro.historical.cerebro_trainer_v2 ^
    --hidden-import=jarvis ^
    --hidden-import=jarvis.jarvis_core ^
    --hidden-import=jarvis.bots ^
    --hidden-import=jarvis.bots.buffett_bot ^
    --hidden-import=jarvis.bots.belfort_bot ^
    --hidden-import=jarvis.bots.standard_bot ^
    --hidden-import=newsapi ^
    --hidden-import=sqlite3 ^
    "%ROOT%launcher\launch.py"

if errorlevel 1 ( echo ERROR: PyInstaller build failed & pause & exit /b 1 )

echo [4/4] Copying exe to Desktop...
powershell -NoProfile -Command "$desktop = (New-Object -ComObject Shell.Application).Namespace('Desktop').Self.Path; Copy-Item -Path '%ROOT%dist\Cerebro Trading.exe' -Destination \"$desktop\Cerebro Trading.exe\" -Force; Write-Host \"Copied to $desktop\Cerebro Trading.exe\""

echo.
echo  Creating Desktop shortcut (.lnk)...
"%PYTHON%" "%ROOT%create_shortcut.py"

echo.
echo  =========================================
echo   Build complete!
echo   Cerebro Trading.exe is on your Desktop.
echo  =========================================
echo.
