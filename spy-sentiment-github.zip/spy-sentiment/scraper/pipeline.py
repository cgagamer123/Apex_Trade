"""
pipeline.py — orchestrates: fetch → filter → score → composite → persist.

Usage:
    from scraper.pipeline import run_pipeline
    result = run_pipeline()
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from scraper.fetchers  import fetch_all
from scraper.processor import filter_relevant, score_articles, compute_composite

log = logging.getLogger(__name__)


def run_pipeline(persist: bool = True) -> dict[str, Any]:
    """
    Run one full pipeline cycle.

    Returns a result dict:
    {
        "run_at":          ISO datetime string (UTC),
        "composite_score": float,
        "signal":          "BULLISH" | "BEARISH" | "NEUTRAL",
        "article_count":   int,
        "total_weight":    float,
        "top_articles":    list[dict],   # top-5 by |score| × weight
    }
    """
    run_at = datetime.now(timezone.utc)
    log.info("=== Pipeline run started at %s ===", run_at.isoformat())

    # 1. Fetch
    articles = fetch_all()

    # 2. Filter for relevance
    articles = filter_relevant(articles)

    # 3. Score (sentiment + decay weight)
    articles = score_articles(articles)

    # 4. Composite signal
    composite = compute_composite(articles)

    # 5. Top-5 articles by |weighted contribution|
    for a in articles:
        a["_contribution"] = abs(a["sentiment_score"] * a["decay_weight"])
    top5 = sorted(articles, key=lambda a: a["_contribution"], reverse=True)[:5]
    top_articles = [
        {
            "title":           a["title"],
            "source":          a["source"],
            "published_at":    a["published_at"].isoformat(),
            "sentiment":       a["sentiment"],
            "sentiment_score": a["sentiment_score"],
            "decay_weight":    a["decay_weight"],
        }
        for a in top5
    ]

    result: dict[str, Any] = {
        "run_at":          run_at.isoformat(),
        **composite,
        "top_articles":    top_articles,
    }

    # 6. Persist to DB
    if persist:
        try:
            from storage.db import save_run
            save_run(result, articles)
        except Exception as exc:
            log.warning("DB persist failed: %s", exc)

    log.info(
        "=== Pipeline done | signal=%s  score=%.4f  articles=%d ===",
        result["signal"], result["composite_score"], result["article_count"],
    )
    return result
