"""
fetchers.py — pulls raw articles from RSS feeds and NewsAPI.
Returns a unified list of dicts:
  { title, description, url, published_at (datetime, UTC), source }
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone, timedelta
from typing import Any

import feedparser

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

log = logging.getLogger(__name__)

# ── helpers ───────────────────────────────────────────────────────────────────

def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _parse_rss_time(entry: Any) -> datetime:
    """Best-effort extraction of a timezone-aware UTC datetime from an RSS entry."""
    for attr in ("published_parsed", "updated_parsed"):
        t = getattr(entry, attr, None)
        if t:
            try:
                return datetime(*t[:6], tzinfo=timezone.utc)
            except Exception:
                pass
    return _utcnow()


def _article(title: str, desc: str, url: str,
             published_at: datetime, source: str) -> dict:
    return {
        "title":        title.strip(),
        "description":  desc.strip(),
        "url":          url.strip(),
        "published_at": published_at,
        "source":       source,
    }


# ── RSS fetcher ───────────────────────────────────────────────────────────────

def fetch_rss(feeds: dict[str, str] | None = None) -> list[dict]:
    """Fetch all configured RSS feeds and return unified article dicts."""
    feeds = feeds or config.RSS_FEEDS
    articles: list[dict] = []
    cutoff = _utcnow() - timedelta(hours=config.MAX_ARTICLE_AGE_HOURS)

    for name, url in feeds.items():
        try:
            parsed = feedparser.parse(url)
            for entry in parsed.entries:
                pub = _parse_rss_time(entry)
                if pub < cutoff:
                    continue
                title = getattr(entry, "title", "") or ""
                desc  = getattr(entry, "summary", "") or ""
                link  = getattr(entry, "link", url) or url
                articles.append(_article(title, desc, link, pub, name))
            log.info("RSS [%s] → %d entries", name, len(parsed.entries))
        except Exception as exc:
            log.warning("RSS fetch failed for %s: %s", name, exc)

    return articles


# ── NewsAPI fetcher ───────────────────────────────────────────────────────────

def fetch_newsapi(api_key: str | None = None) -> list[dict]:
    """Fetch from NewsAPI. Silently skips if key is placeholder."""
    api_key = api_key or config.NEWSAPI_KEY
    if not api_key or api_key.startswith("YOUR_"):
        log.info("NewsAPI key not set — skipping NewsAPI fetch.")
        return []

    try:
        from newsapi import NewsApiClient  # type: ignore
    except ImportError:
        log.warning("newsapi-python not installed; skipping NewsAPI fetch.")
        return []

    articles: list[dict] = []
    cutoff = _utcnow() - timedelta(hours=config.MAX_ARTICLE_AGE_HOURS)

    try:
        client = NewsApiClient(api_key=api_key)
        resp = client.get_everything(
            q=config.NEWSAPI_QUERY,
            language="en",
            sort_by="publishedAt",
            page_size=config.NEWSAPI_PAGE_SIZE,
        )
        for item in resp.get("articles", []):
            raw_pub = item.get("publishedAt", "")
            try:
                pub = datetime.fromisoformat(raw_pub.replace("Z", "+00:00"))
            except Exception:
                pub = _utcnow()
            if pub < cutoff:
                continue
            articles.append(_article(
                title       = item.get("title") or "",
                desc        = item.get("description") or "",
                url         = item.get("url") or "",
                published_at= pub,
                source      = item.get("source", {}).get("name", "newsapi"),
            ))
        log.info("NewsAPI → %d articles", len(articles))
    except Exception as exc:
        log.warning("NewsAPI fetch failed: %s", exc)

    return articles


# ── combined fetcher ──────────────────────────────────────────────────────────

def fetch_all() -> list[dict]:
    """Return de-duplicated articles from all sources, sorted newest-first."""
    raw = fetch_rss() + fetch_newsapi()

    # deduplicate by URL
    seen: set[str] = set()
    unique: list[dict] = []
    for art in raw:
        if art["url"] not in seen:
            seen.add(art["url"])
            unique.append(art)

    unique.sort(key=lambda a: a["published_at"], reverse=True)
    log.info("Total unique articles fetched: %d", len(unique))
    return unique
