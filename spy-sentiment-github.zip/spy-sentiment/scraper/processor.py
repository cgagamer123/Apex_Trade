"""
processor.py — FinBERT sentiment scoring + exponential recency-decay weighting.

Each article dict gains three new keys:
  sentiment      : "positive" | "negative" | "neutral"
  sentiment_score: float in [-1, +1]  (positive=+1, negative=-1, neutral=0)
  decay_weight   : float in (0, 1]    (1.0 = published right now)
"""

from __future__ import annotations

import logging
import math
from datetime import datetime, timezone
from typing import Any

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

log = logging.getLogger(__name__)

# ── FinBERT loader (lazy singleton) ──────────────────────────────────────────

_pipeline = None


def _get_pipeline():
    global _pipeline
    if _pipeline is None:
        try:
            from transformers import pipeline as hf_pipeline  # type: ignore
            log.info("Loading FinBERT model (first run may download ~500 MB)…")
            _pipeline = hf_pipeline(
                "text-classification",
                model="ProsusAI/finbert",
                tokenizer="ProsusAI/finbert",
                top_k=None,           # return all three class scores
                device=-1,            # CPU; set to 0 for GPU
            )
            log.info("FinBERT loaded.")
        except Exception as exc:
            log.error("Failed to load FinBERT: %s", exc)
            _pipeline = None
    return _pipeline


# ── sentiment helpers ─────────────────────────────────────────────────────────

_LABEL_SCORE = {"positive": 1.0, "negative": -1.0, "neutral": 0.0}


def _score_text(text: str) -> tuple[str, float]:
    """
    Run FinBERT on up to 512 tokens of text.
    Returns (label, scalar_score) where scalar_score ∈ [-1, +1].
    Falls back to neutral on any error.
    """
    pipe = _get_pipeline()
    if pipe is None or not text.strip():
        return "neutral", 0.0

    try:
        # FinBERT max input is 512 tokens; truncate by characters as cheap proxy
        truncated = text[:1500]
        results: list[dict] = pipe(truncated)[0]  # list of {label, score}

        # pick the highest-confidence label
        best = max(results, key=lambda r: r["score"])
        label = best["label"].lower()
        # weighted scalar: sum(prob * direction)
        scalar = sum(
            r["score"] * _LABEL_SCORE.get(r["label"].lower(), 0.0)
            for r in results
        )
        return label, round(scalar, 4)
    except Exception as exc:
        log.warning("FinBERT inference error: %s", exc)
        return "neutral", 0.0


# ── decay helper ──────────────────────────────────────────────────────────────

def _decay_weight(published_at: datetime) -> float:
    """
    Exponential half-life decay.
    weight = exp(-ln(2) / HALF_LIFE_HOURS * age_hours)
    """
    now = datetime.now(timezone.utc)
    age_hours = max((now - published_at).total_seconds() / 3600.0, 0.0)
    decay = math.exp(-math.log(2) / config.HALF_LIFE_HOURS * age_hours)
    return round(decay, 6)


# ── keyword filter ────────────────────────────────────────────────────────────

def _is_relevant(article: dict, keywords: list[str] | None = None) -> bool:
    keywords = keywords or config.SPY_KEYWORDS
    haystack = (
        (article.get("title") or "") + " " +
        (article.get("description") or "")
    ).lower()
    return any(kw.lower() in haystack for kw in keywords)


# ── public API ────────────────────────────────────────────────────────────────

def filter_relevant(articles: list[dict]) -> list[dict]:
    """Keep only articles that mention SPY/market keywords."""
    relevant = [a for a in articles if _is_relevant(a)]
    log.info("Relevance filter: %d / %d articles kept", len(relevant), len(articles))
    return relevant


def score_articles(articles: list[dict]) -> list[dict]:
    """
    Adds sentiment + decay_weight to each article dict (in-place).
    Returns the same list for chaining.
    """
    for art in articles:
        text = f"{art.get('title', '')}. {art.get('description', '')}"
        label, scalar = _score_text(text)
        art["sentiment"]       = label
        art["sentiment_score"] = scalar
        art["decay_weight"]    = _decay_weight(art["published_at"])

    log.info("Scored %d articles.", len(articles))
    return articles


def compute_composite(articles: list[dict]) -> dict[str, Any]:
    """
    Weighted average sentiment score across all scored articles.

    composite_score = Σ(sentiment_score_i * decay_weight_i) / Σ(decay_weight_i)

    Returns a summary dict with composite_score and signal label.
    """
    if not articles:
        return {
            "composite_score": 0.0,
            "signal":          "NEUTRAL",
            "article_count":   0,
            "total_weight":    0.0,
        }

    total_weight    = sum(a["decay_weight"] for a in articles)
    weighted_sum    = sum(a["sentiment_score"] * a["decay_weight"] for a in articles)
    composite_score = round(weighted_sum / total_weight, 4) if total_weight else 0.0

    if composite_score >= config.SIGNAL_BULL_THRESHOLD:
        signal = "BULLISH"
    elif composite_score <= config.SIGNAL_BEAR_THRESHOLD:
        signal = "BEARISH"
    else:
        signal = "NEUTRAL"

    return {
        "composite_score": composite_score,
        "signal":          signal,
        "article_count":   len(articles),
        "total_weight":    round(total_weight, 4),
    }
