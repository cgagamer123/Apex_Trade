"""Generate tray and app icons programmatically using Pillow."""
from PIL import Image, ImageDraw, ImageFont
import os

OUT = os.path.dirname(os.path.abspath(__file__))


def make_tray(color: tuple, filename: str, size: int = 64):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    margin = 4
    d.ellipse([margin, margin, size - margin, size - margin], fill=color)
    img.save(os.path.join(OUT, filename))
    print(f"  Saved {filename}")


def make_app_icon(filename_ico: str, filename_png: str, size: int = 256):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # Dark background circle
    d.ellipse([0, 0, size, size], fill=(13, 17, 23, 255))
    # Outer ring
    d.ellipse([4, 4, size - 4, size - 4], outline=(56, 139, 253, 255), width=6)
    # Green dot (top-right, running indicator)
    dot = size // 6
    d.ellipse([size - dot * 2, 10, size - 10, 10 + dot], fill=(63, 185, 80, 255))
    # "C" letter
    cx, cy, r = size // 2, size // 2, size // 3
    d.arc([cx - r, cy - r, cx + r, cy + r], start=45, end=315,
          fill=(255, 255, 255, 255), width=size // 10)

    # Save PNG
    png_path = os.path.join(OUT, filename_png)
    img.save(png_path)
    print(f"  Saved {filename_png}")

    # Save ICO (multiple sizes)
    ico_path = os.path.join(OUT, filename_ico)
    sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    imgs = [img.resize(s, Image.LANCZOS) for s in sizes]
    imgs[0].save(ico_path, format="ICO", sizes=sizes,
                 append_images=imgs[1:])
    print(f"  Saved {filename_ico}")


if __name__ == "__main__":
    print("Generating icons...")
    make_tray((63, 185, 80, 255),  "tray_green.png")   # green = running
    make_tray((248, 81, 73, 255),  "tray_red.png")     # red   = paused
    make_app_icon("icon.ico", "icon.png")
    print("Done.")
