"""
dashboard/app.py — Flask dashboard server for SPY Sentiment Trading System.
Reads live data from SQLite DBs and serves a single-page dashboard.

Run:  python dashboard/app.py
URL:  http://localhost:5000
"""

from __future__ import annotations

import json
import os
import sqlite3
import sys
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta, date
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

# ── path setup ────────────────────────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import config

app = Flask(__name__, static_folder=str(Path(__file__).parent))

# ── DB helpers ────────────────────────────────────────────────────────────────

@contextmanager
def _conn(db_path: str):
    c = sqlite3.connect(db_path)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def _init_bots_table():
    """Ensure bots config table exists in TRADE_DB."""
    with _conn(config.TRADE_DB) as c:
        c.executescript("""
            CREATE TABLE IF NOT EXISTS bots (
                name       TEXT PRIMARY KEY,
                enabled    INTEGER DEFAULT 1,
                strategy   TEXT,
                delta_tag  TEXT,
                dte_tag    TEXT,
                style_tag  TEXT
            );

            CREATE TABLE IF NOT EXISTS bot_trades (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                bot        TEXT NOT NULL,
                trade_id   TEXT,
                direction  TEXT,
                contract   TEXT,
                strike     REAL,
                expiry     TEXT,
                premium    REAL,
                contracts  INTEGER,
                total_cost REAL,
                entry_time TEXT,
                exit_premium REAL,
                pnl        REAL,
                exit_reason TEXT,
                exit_time  TEXT,
                status     TEXT DEFAULT 'OPEN'
            );

            CREATE INDEX IF NOT EXISTS idx_bt_bot    ON bot_trades(bot);
            CREATE INDEX IF NOT EXISTS idx_bt_status ON bot_trades(status);
            CREATE INDEX IF NOT EXISTS idx_bt_time   ON bot_trades(entry_time);
        """)
        # Seed default bot configs if not present
        defaults = [
            ("buffett",  1, "Value/Momentum",    "0.60-0.70 delta", "30-45 DTE", "Conservative"),
            ("belfort",  1, "Momentum/Breakout",  "0.40-0.55 delta", "7-14 DTE",  "Aggressive"),
            ("standard", 1, "Balanced Swing",     "0.45-0.55 delta", "21-30 DTE", "Balanced"),
            ("ultron",   1, "ML-Driven Live",     "0.50 delta",      "7-21 DTE",  "Adaptive"),
        ]
        for row in defaults:
            c.execute("""
                INSERT OR IGNORE INTO bots (name, enabled, strategy, delta_tag, dte_tag, style_tag)
                VALUES (?,?,?,?,?,?)
            """, row)


def _init_pdt():
    try:
        with _conn(config.PDT_DB) as c:
            c.execute("""
                CREATE TABLE IF NOT EXISTS pdt_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trade_id TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    action TEXT NOT NULL,
                    timestamp TEXT NOT NULL
                )
            """)
    except Exception:
        pass


def _safe_float(v, default=0.0):
    try:
        return float(v) if v is not None else default
    except Exception:
        return default


# ── market hours helper ───────────────────────────────────────────────────────

def _market_status() -> str:
    now = datetime.now(timezone(timedelta(hours=-4)))   # ET approx
    if now.weekday() >= 5:
        return "CLOSED"
    t = now.time()
    from datetime import time as dtime
    if dtime(9, 30) <= t <= dtime(16, 0):
        return "OPEN"
    elif dtime(4, 0) <= t < dtime(9, 30):
        return "PRE-MARKET"
    elif dtime(16, 0) < t <= dtime(20, 0):
        return "AFTER-HOURS"
    return "CLOSED"


# ── data readers ──────────────────────────────────────────────────────────────

def _latest_sentiment() -> dict:
    try:
        with _conn(config.DB_PATH) as c:
            row = c.execute(
                "SELECT * FROM runs ORDER BY run_at DESC LIMIT 1"
            ).fetchone()
        if row:
            return {
                "composite_score": _safe_float(row["composite_score"]),
                "signal":          row["signal"],
                "run_at":          row["run_at"],
                "article_count":   row["article_count"],
            }
    except Exception:
        pass
    return {"composite_score": 0.0, "signal": "NEUTRAL", "run_at": None, "article_count": 0}


def _pdt_status() -> dict:
    try:
        sys.path.insert(0, str(ROOT))
        from pdt_tracker import get_pdt_status
        return get_pdt_status()
    except Exception:
        return {"day_trades_used": 0, "day_trades_remaining": 3,
                "blocked": False, "resets_on": "N/A"}


def _risk_data() -> dict:
    try:
        from risk_manager import risk_summary
        return risk_summary()
    except Exception:
        return {
            "account_size": config.ACCOUNT_SIZE,
            "buying_power": config.BUYING_POWER,
            "open_position_cost": 0.0,
            "max_position_size": config.MAX_POSITION_SIZE,
            "risk_remaining": config.MAX_POSITION_SIZE,
            "max_risk_per_trade": config.MAX_RISK_PER_TRADE,
        }


def _today_pnl() -> float:
    try:
        today = date.today().isoformat()
        with _conn(config.TRADE_DB) as c:
            row = c.execute(
                """SELECT COALESCE(SUM(pnl),0) as total FROM bot_trades
                   WHERE status='CLOSED' AND exit_time >= ?""",
                (today,),
            ).fetchone()
        return _safe_float(row["total"]) if row else 0.0
    except Exception:
        return 0.0


def _bot_stats(bot_name: str) -> dict:
    try:
        with _conn(config.TRADE_DB) as c:
            total = c.execute(
                "SELECT COUNT(*) as n FROM bot_trades WHERE bot=?", (bot_name,)
            ).fetchone()["n"]
            wins = c.execute(
                "SELECT COUNT(*) as n FROM bot_trades WHERE bot=? AND pnl > 0 AND status='CLOSED'",
                (bot_name,),
            ).fetchone()["n"]
            closed = c.execute(
                "SELECT COUNT(*) as n FROM bot_trades WHERE bot=? AND status='CLOSED'",
                (bot_name,),
            ).fetchone()["n"]
            avg_pnl_row = c.execute(
                "SELECT AVG(pnl) as avg FROM bot_trades WHERE bot=? AND status='CLOSED'",
                (bot_name,),
            ).fetchone()
        win_rate = round(wins / closed * 100, 1) if closed > 0 else 0.0
        return {
            "total_trades": total,
            "win_rate":     win_rate,
            "avg_pnl":      round(_safe_float(avg_pnl_row["avg"]), 2),
            "closed_trades": closed,
        }
    except Exception:
        return {"total_trades": 0, "win_rate": 0.0, "avg_pnl": 0.0, "closed_trades": 0}


def _pdt_used_by_bot(bot_name: str) -> int:
    try:
        today = date.today().isoformat()
        with _conn(config.TRADE_DB) as c:
            row = c.execute(
                """SELECT COUNT(*) as n FROM bot_trades
                   WHERE bot=? AND status='CLOSED' AND exit_time >= ?""",
                (bot_name, today),
            ).fetchone()
        return row["n"] if row else 0
    except Exception:
        return 0


def _current_signal_for_bot(bot_name: str, sentiment: dict, pdt: dict) -> str:
    if pdt["blocked"]:
        return "BLOCKED (PDT)"
    sig = sentiment.get("signal", "NEUTRAL")
    if sig == "NEUTRAL":
        return "SKIP (NEUTRAL)"
    action_map = {
        "buffett":  {"BULLISH": "PAPER BUY CALL", "BEARISH": "PAPER BUY PUT"},
        "belfort":  {"BULLISH": "BUY CALL",        "BEARISH": "BUY PUT"},
        "standard": {"BULLISH": "BUY CALL",        "BEARISH": "BUY PUT"},
        "ultron":   {"BULLISH": "LIVE BUY CALL",   "BEARISH": "LIVE BUY PUT"},
    }
    return action_map.get(bot_name, {}).get(sig, "SKIP")


# ── API routes ────────────────────────────────────────────────────────────────

@app.route("/api/status")
def api_status():
    _init_bots_table()
    _init_pdt()

    sentiment = _latest_sentiment()
    pdt       = _pdt_status()
    risk      = _risk_data()
    today_pnl = _today_pnl()

    # Synthetic per-source breakdown (scaled from composite with light noise)
    base = sentiment["composite_score"]
    import random; random.seed(42)   # deterministic until next real run
    sources = {
        "news":   round(base + random.uniform(-0.05, 0.05), 3),
        "social": round(base + random.uniform(-0.10, 0.10), 3),
        "flow":   round(base + random.uniform(-0.08, 0.08), 3),
        "macro":  round(base + random.uniform(-0.12, 0.12), 3),
    }

    return jsonify({
        "account": {
            "size":      risk["account_size"],
            "used":      risk["open_position_cost"],
            "free":      risk["account_size"] - risk["open_position_cost"],
            "today_pnl": today_pnl,
        },
        "pdt":       pdt,
        "sentiment": {**sentiment, "sources": sources},
        "market_status":      _market_status(),
        "cerebro_accuracy":   72.4,   # placeholder — replace with real model metric
    })


@app.route("/api/trades")
def api_trades():
    _init_bots_table()
    try:
        with _conn(config.TRADE_DB) as c:
            rows = c.execute(
                """SELECT * FROM bot_trades ORDER BY entry_time DESC LIMIT 50"""
            ).fetchall()
        return jsonify([dict(r) for r in rows])
    except Exception as e:
        return jsonify([])


@app.route("/api/bots")
def api_bots():
    _init_bots_table()
    sentiment = _latest_sentiment()
    pdt       = _pdt_status()

    try:
        with _conn(config.TRADE_DB) as c:
            bot_rows = c.execute("SELECT * FROM bots").fetchall()
    except Exception:
        return jsonify([])

    result = []
    for b in bot_rows:
        name  = b["name"]
        stats = _bot_stats(name)
        result.append({
            "name":           name,
            "enabled":        bool(b["enabled"]),
            "strategy":       b["strategy"],
            "delta_tag":      b["delta_tag"],
            "dte_tag":        b["dte_tag"],
            "style_tag":      b["style_tag"],
            "win_rate":       stats["win_rate"],
            "total_trades":   stats["total_trades"],
            "avg_pnl":        stats["avg_pnl"],
            "pdt_used":       _pdt_used_by_bot(name),
            "current_signal": _current_signal_for_bot(name, sentiment, pdt),
        })
    return jsonify(result)


@app.route("/api/bot/toggle", methods=["POST"])
def api_bot_toggle():
    _init_bots_table()
    data = request.get_json(silent=True) or {}
    bot_name = data.get("bot", "").lower()
    enabled  = bool(data.get("enabled", True))

    if not bot_name:
        return jsonify({"error": "bot name required"}), 400

    try:
        with _conn(config.TRADE_DB) as c:
            c.execute(
                "UPDATE bots SET enabled=? WHERE name=?",
                (1 if enabled else 0, bot_name),
            )
        return jsonify({"bot": bot_name, "enabled": enabled, "ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/")
def index():
    return send_from_directory(str(Path(__file__).parent), "index.html")


# ── Cerebro report routes ─────────────────────────────────────────────────────

REPORTS_DIR = ROOT / "reports"

def _read_report(filename: str) -> dict | None:
    path = REPORTS_DIR / filename
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return None


@app.route("/api/cerebro_report")
def cerebro_report():
    report = _read_report("cerebro_report.json")
    if not report:
        return jsonify({"error": "Cerebro report not available yet",
                        "hint": "Cerebro engine is starting up..."}), 404
    return jsonify(report)


@app.route("/api/weekly_report")
def weekly_report():
    report = _read_report("cerebro_weekly_report.json")
    if not report:
        return jsonify({"error": "Weekly report not available yet"}), 404
    return jsonify(report)


@app.route("/api/signals")
def latest_signals():
    """Latest signal from each bot (last row per bot from bot_trades)."""
    _init_bots_table()
    signals = {}
    try:
        with _conn(config.TRADE_DB) as c:
            for bot_name in ("buffett", "belfort", "standard", "ultron"):
                row = c.execute(
                    """SELECT action, direction, strategy, confidence, reason,
                              entry_time, spy_price
                       FROM bot_trades WHERE bot = ?
                       ORDER BY entry_time DESC LIMIT 1""",
                    (bot_name,),
                ).fetchone()
                if row:
                    signals[bot_name] = dict(row)
                else:
                    signals[bot_name] = None
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify(signals)


@app.route("/api/bot/force_signal", methods=["POST"])
def force_signal():
    """Manually trigger a signal check for a specific bot."""
    data     = request.get_json(force=True) or {}
    bot_name = data.get("bot", "").lower()
    if bot_name not in ("buffett", "belfort", "standard"):
        return jsonify({"error": "Unknown bot"}), 400

    report = _read_report("cerebro_report.json")
    if not report:
        return jsonify({"error": "No Cerebro report available"}), 503

    try:
        if bot_name == "buffett":
            from jarvis.bots.buffett_bot import BuffettBot
            sig = BuffettBot().generate_signal(report)
        elif bot_name == "belfort":
            from jarvis.bots.belfort_bot import BelfortBot
            sig = BelfortBot().generate_signal(report)
        else:
            from jarvis.bots.standard_bot import StandardBot
            sig = StandardBot().generate_signal(report)
        return jsonify(sig)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    _init_bots_table()
    _init_pdt()
    print()
    print("=" * 50)
    print("  SPY Dashboard starting on http://localhost:5000")
    print("=" * 50)
    print()
    app.run(host="0.0.0.0", port=5000, debug=False)
