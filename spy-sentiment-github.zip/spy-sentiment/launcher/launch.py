"""
launch.py — Cerebro Trading System entry point.

1. Shows tkinter splash screen while loading
2. Auto-installs missing pip dependencies
3. Starts Flask dashboard + bot runner as subprocesses
4. Opens browser to http://localhost:5000
5. Creates a pystray system-tray icon for control
6. Shows a Windows toast notification on startup
"""

from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

# Frozen-exe-aware ROOT — data/project dir, not the temp extraction dir
if getattr(sys, 'frozen', False):
    ROOT = Path(r"C:\spy-sentiment")
else:
    ROOT = Path(__file__).resolve().parent.parent

sys.path.insert(0, str(ROOT))

DASHBOARD_URL = "http://localhost:5000"

# ── dependency check ──────────────────────────────────────────────────────────

def ensure_deps(set_step_fn=None) -> None:
    """Check/install deps.  When frozen, all deps are bundled — skip pip."""
    if getattr(sys, 'frozen', False):
        return  # PyInstaller already bundled everything

    import importlib
    pkg_map = {
        "flask": "flask", "transformers": "transformers", "torch": "torch",
        "feedparser": "feedparser", "pandas": "pandas", "schedule": "schedule",
        "pystray": "pystray", "Pillow": "PIL", "newsapi-python": "newsapi",
    }
    missing = [pip for pip, mod in pkg_map.items()
               if importlib.util.find_spec(mod) is None]
    if missing:
        if set_step_fn:
            set_step_fn(0)
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "--quiet", *missing],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )


# ── Windows toast notification ────────────────────────────────────────────────

def _toast(title: str, msg: str) -> None:
    try:
        from win10toast import ToastNotifier  # type: ignore
        ToastNotifier().show_toast(title, msg, duration=4, threaded=True)
    except Exception:
        try:
            # Fallback: PowerShell balloon
            ps = (
                f"Add-Type -AssemblyName System.Windows.Forms; "
                f"$n = New-Object System.Windows.Forms.NotifyIcon; "
                f"$n.Icon = [System.Drawing.SystemIcons]::Information; "
                f"$n.Visible = $true; "
                f"$n.ShowBalloonTip(4000, '{title}', '{msg}', "
                f"[System.Windows.Forms.ToolTipIcon]::Info)"
            )
            subprocess.Popen(
                ["powershell", "-NoProfile", "-Command", ps],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        except Exception:
            pass  # notifications optional


# ── wait for Flask to be ready ────────────────────────────────────────────────

def _wait_for_flask(timeout: int = 30) -> bool:
    import urllib.request
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(DASHBOARD_URL, timeout=1)
            return True
        except Exception:
            time.sleep(0.5)
    return False


# ── tray icon ─────────────────────────────────────────────────────────────────

def _load_tray_image(name: str):
    from PIL import Image
    path = ROOT / "assets" / name
    if path.exists():
        return Image.open(path).resize((22, 22))
    # Fallback: generate on the fly
    img = Image.new("RGBA", (22, 22), (0, 0, 0, 0))
    from PIL import ImageDraw
    d = ImageDraw.Draw(img)
    color = (63, 185, 80, 255) if "green" in name else (248, 81, 73, 255)
    d.ellipse([2, 2, 20, 20], fill=color)
    return img


def _build_tray_icon(pm):
    import pystray
    from pystray import MenuItem as Item, Menu

    def open_dashboard(icon, item):
        webbrowser.open(DASHBOARD_URL)

    def pause_jarvis(icon, item):
        pm.pause_bots()
        icon.icon  = _load_tray_image("tray_red.png")
        icon.title = "Cerebro OK · Jarvis PAUSED"

    def resume_jarvis(icon, item):
        pm.resume_bots()
        pm.start_jarvis()   # restart Jarvis threads if they stopped
        icon.icon  = _load_tray_image("tray_green.png")
        icon.title = "Cerebro + Jarvis Running"

    def view_cerebro_log(icon, item):
        log_path = ROOT / "logs" / "cerebro.log"
        log_path.touch()
        os.startfile(str(log_path))

    def view_jarvis_log(icon, item):
        log_path = ROOT / "logs" / "jarvis.log"
        log_path.touch()
        os.startfile(str(log_path))

    def quit_app(icon, item):
        pm.stop_all()
        icon.stop()

    menu = Menu(
        Item("Open Dashboard",    open_dashboard, default=True),
        Menu.SEPARATOR,
        Item("Pause Jarvis",      pause_jarvis),
        Item("Resume Jarvis",     resume_jarvis),
        Menu.SEPARATOR,
        Item("View Cerebro Log",  view_cerebro_log),
        Item("View Jarvis Log",   view_jarvis_log),
        Menu.SEPARATOR,
        Item("Quit",              quit_app),
    )

    icon = pystray.Icon(
        "cerebro",
        _load_tray_image("tray_green.png"),
        "Cerebro + Jarvis Running",
        menu,
    )
    return icon


# ── main startup sequence ─────────────────────────────────────────────────────

def main() -> None:
    # Import splash — may not be available in frozen exe until deps installed
    try:
        from launcher.splash import show_splash, set_step, close_splash, show_error
    except ImportError:
        from splash import show_splash, set_step, close_splash, show_error

    try:
        from launcher import process_manager as pm
    except ImportError:
        import process_manager as pm

    # Launch splash in background (it runs its own mainloop)
    splash_thread = threading.Thread(target=show_splash, daemon=True)
    splash_thread.start()
    time.sleep(0.3)   # let window appear

    try:
        # Step 0 — deps
        set_step(0)
        ensure_deps(set_step)

        # Step 1 — DB init
        set_step(1)
        sys.path.insert(0, str(ROOT))
        from storage.db   import init_db
        from trade_logger import _init as tl_init
        from pdt_tracker  import _init as pt_init
        init_db()
        tl_init()
        pt_init()
        time.sleep(0.4)

        # Step 2 — FinBERT (just warm-up import, model loads lazily on first run)
        set_step(2)
        time.sleep(0.3)

        # Step 3 — Start Flask
        set_step(3)
        pm.start_all()
        time.sleep(1.5)

        # Step 4 — Wait for Flask
        set_step(4)
        ok = _wait_for_flask(timeout=20)
        if not ok:
            show_error("Flask dashboard did not start in time.")
            time.sleep(4)

        # Step 5 — Open browser
        set_step(5)
        webbrowser.open(DASHBOARD_URL)
        time.sleep(0.5)

        # Step 6 — Ready
        set_step(6)
        time.sleep(0.8)

    except Exception as exc:
        show_error(str(exc))
        time.sleep(6)

    close_splash()

    # Toast notification
    _toast("Cerebro Trading System", "System started — dashboard open in browser.")

    # System tray (blocks until Quit)
    icon = _build_tray_icon(pm)
    icon.run()


if __name__ == "__main__":
    main()
