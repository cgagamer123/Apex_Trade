"""
process_manager.py — Manages Cerebro (background engine) and Jarvis (interface).

Architecture:
  Cerebro  — silent 24/7 data engine. NEVER stops. Writes cerebro.log only.
  Jarvis   — signal interface + Flask dashboard. Can be paused/restarted.

Tray icon:
  Green  = both running
  Yellow = Cerebro only (Jarvis paused)
  Red    = neither running

Public API:
  start_cerebro()    → start Cerebro engine thread (never stops)
  start_jarvis()     → start Jarvis core + Flask dashboard threads
  stop_jarvis()      → stop Jarvis (Cerebro keeps running)
  stop_all()         → stop everything
  pause_bots()       → write pause.flag (Jarvis sees it, skips signal loop)
  resume_bots()      → remove pause.flag
  is_cerebro_alive() → bool
  is_jarvis_alive()  → bool
  get_status()       → {cerebro, jarvis, flask, paused}
"""

from __future__ import annotations

import logging
import sys
import threading
from pathlib import Path

# Frozen-exe-aware ROOT — data/project dir, not _MEIPASS temp dir
if getattr(sys, 'frozen', False):
    ROOT = Path(r"C:\spy-sentiment")
else:
    ROOT = Path(__file__).resolve().parent.parent

sys.path.insert(0, str(ROOT))

PAUSE_FLAG = ROOT / "pause.flag"
LOG_DIR    = ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

log = logging.getLogger("cerebro.pm")

# ---------------------------------------------------------------------------
# PyInstaller import tracing (if False = never executed, just traced at build)
# ---------------------------------------------------------------------------
if False:  # pragma: no cover
    import main                           # noqa: F401
    import config                         # noqa: F401
    import scraper.pipeline               # noqa: F401
    import scraper.fetchers               # noqa: F401
    import scraper.processor              # noqa: F401
    import storage.db                     # noqa: F401
    import pdt_tracker                    # noqa: F401
    import risk_manager                   # noqa: F401
    import trade_logger                   # noqa: F401
    from dashboard.app import app         # noqa: F401
    import cerebro.cerebro_engine         # noqa: F401
    import cerebro.report_compiler        # noqa: F401
    import jarvis.jarvis_core             # noqa: F401
    import jarvis.bots.buffett_bot        # noqa: F401
    import jarvis.bots.belfort_bot        # noqa: F401
    import jarvis.bots.standard_bot       # noqa: F401

# ---------------------------------------------------------------------------
# Thread state
# ---------------------------------------------------------------------------
_cerebro_thread: threading.Thread | None = None
_jarvis_thread:  threading.Thread | None = None
_flask_thread:   threading.Thread | None = None

_cerebro_alive = False
_jarvis_alive  = False
_flask_alive   = False


# ---------------------------------------------------------------------------
# Thread targets
# ---------------------------------------------------------------------------

def _run_cerebro() -> None:
    global _cerebro_alive
    _cerebro_alive = True
    log.info("Cerebro engine thread starting...")
    try:
        sys.path.insert(0, str(ROOT))
        from cerebro.cerebro_engine import main as cerebro_main
        cerebro_main()
    except Exception as exc:
        log.error("Cerebro engine crashed: %s", exc)
    finally:
        _cerebro_alive = False
        log.warning("Cerebro engine thread stopped")


def _run_flask() -> None:
    global _flask_alive
    _flask_alive = True
    log.info("Flask dashboard thread starting on :5000 ...")
    try:
        sys.path.insert(0, str(ROOT))
        from dashboard.app import app, _init_bots_table
        _init_bots_table()
        app.run(host="0.0.0.0", port=5000, threaded=True,
                use_reloader=False, debug=False)
    except Exception as exc:
        log.error("Flask crashed: %s", exc)
    finally:
        _flask_alive = False


def _run_jarvis() -> None:
    global _jarvis_alive
    _jarvis_alive = True
    log.info("Jarvis core thread starting...")
    try:
        sys.path.insert(0, str(ROOT))
        from jarvis.jarvis_core import JarvisCore
        JarvisCore().run()
    except Exception as exc:
        log.error("Jarvis crashed: %s", exc)
    finally:
        _jarvis_alive = False


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def start_cerebro() -> None:
    """Start the Cerebro background engine (24/7, never stops)."""
    global _cerebro_thread
    PAUSE_FLAG.unlink(missing_ok=True)
    if not _cerebro_alive:
        _cerebro_thread = threading.Thread(
            target=_run_cerebro, daemon=True, name="cerebro-engine")
        _cerebro_thread.start()
        log.info("Cerebro engine started")


def start_jarvis() -> None:
    """Start Jarvis core + Flask dashboard."""
    global _flask_thread, _jarvis_thread
    PAUSE_FLAG.unlink(missing_ok=True)

    if not _flask_alive:
        _flask_thread = threading.Thread(
            target=_run_flask, daemon=True, name="cerebro-flask")
        _flask_thread.start()

    if not _jarvis_alive:
        _jarvis_thread = threading.Thread(
            target=_run_jarvis, daemon=True, name="cerebro-jarvis")
        _jarvis_thread.start()


def start_all() -> None:
    """Start Cerebro + Jarvis (convenience wrapper for launcher)."""
    start_cerebro()
    start_jarvis()


def stop_jarvis() -> None:
    """Pause Jarvis by writing pause.flag (Cerebro keeps running)."""
    PAUSE_FLAG.write_text("paused")
    log.info("Jarvis paused (pause.flag written)")


def stop_all() -> None:
    """Signal all threads to stop (daemon threads die with main process)."""
    PAUSE_FLAG.unlink(missing_ok=True)
    log.info("stop_all called — daemon threads will die with main process")


def pause_bots() -> None:
    PAUSE_FLAG.write_text("paused")


def resume_bots() -> None:
    PAUSE_FLAG.unlink(missing_ok=True)


def is_cerebro_alive() -> bool:
    return _cerebro_alive


def is_jarvis_alive() -> bool:
    return _jarvis_alive


def is_running() -> bool:
    return _cerebro_alive and _flask_alive


def get_status() -> dict:
    return {
        "cerebro": _cerebro_alive,
        "jarvis":  _jarvis_alive,
        "flask":   _flask_alive,
        "paused":  PAUSE_FLAG.exists(),
    }
