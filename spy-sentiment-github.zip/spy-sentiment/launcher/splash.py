"""
splash.py — Tkinter loading screen shown on startup.

Shows a dark splash window with CEREBRO branding and a live progress bar.
Call show_splash() in a background thread; call close_splash() when ready.
"""

from __future__ import annotations

import threading
import time
import tkinter as tk
from tkinter import ttk
from pathlib import Path

_root: tk.Tk | None = None
_label_step: tk.Label | None = None
_progress: ttk.Progressbar | None = None
_error_label: tk.Label | None = None
_lock = threading.Lock()

STEPS = [
    "Checking dependencies...",
    "Initialising database...",
    "Loading FinBERT model...",
    "Starting Flask dashboard...",
    "Starting bot runner...",
    "Opening browser...",
    "Ready!",
]


def _build_ui(root: tk.Tk) -> None:
    root.title("Cerebro")
    root.geometry("480x300")
    root.configure(bg="#0d1117")
    root.resizable(False, False)
    root.overrideredirect(True)   # borderless

    # Center on screen
    root.update_idletasks()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    x  = (sw - 480) // 2
    y  = (sh - 300) // 2
    root.geometry(f"480x300+{x}+{y}")

    # Title
    tk.Label(root, text="CEREBRO", bg="#0d1117", fg="#ffffff",
             font=("Segoe UI", 36, "bold")).pack(pady=(40, 2))
    tk.Label(root, text="SPY Options Sentiment Trading System",
             bg="#0d1117", fg="#8b949e",
             font=("Segoe UI", 11)).pack()

    tk.Frame(root, bg="#30363d", height=1).pack(fill="x", padx=40, pady=20)

    global _label_step
    _label_step = tk.Label(root, text="Starting...", bg="#0d1117", fg="#c9d1d9",
                           font=("Segoe UI", 10))
    _label_step.pack()

    global _progress
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("green.Horizontal.TProgressbar",
                    troughcolor="#161b22", background="#3fb950",
                    darkcolor="#3fb950", lightcolor="#3fb950", bordercolor="#30363d")
    _progress = ttk.Progressbar(root, style="green.Horizontal.TProgressbar",
                                 length=380, mode="determinate", maximum=len(STEPS))
    _progress.pack(pady=10)

    global _error_label
    _error_label = tk.Label(root, text="", bg="#0d1117", fg="#f85149",
                            font=("Segoe UI", 9), wraplength=440)
    _error_label.pack(pady=4)

    tk.Label(root, text="v1.0", bg="#0d1117", fg="#30363d",
             font=("Segoe UI", 8)).pack(side="bottom", pady=8)


def show_splash() -> None:
    """Create and display the splash window (call from main thread or early thread)."""
    global _root
    _root = tk.Tk()
    _build_ui(_root)
    _root.mainloop()


def set_step(index: int) -> None:
    """Update progress to step `index` (0-based)."""
    with _lock:
        if _root and _label_step and _progress:
            text = STEPS[index] if index < len(STEPS) else "Ready!"
            _root.after(0, lambda: _label_step.config(text=text))
            _root.after(0, lambda: _progress.config(value=index + 1))


def show_error(msg: str) -> None:
    """Show an error message in red; keeps window open."""
    with _lock:
        if _root and _error_label:
            _root.after(0, lambda: _error_label.config(text=f"ERROR: {msg}"))


def close_splash() -> None:
    """Close the splash window."""
    with _lock:
        if _root:
            _root.after(500, _root.destroy)
