@echo off
cd C:\spy-sentiment
C:\Users\funny\AppData\Local\Programs\Python\Python312\python.exe -c "print(42)" > C:\spy-sentiment\test_out.txt 2>&1
