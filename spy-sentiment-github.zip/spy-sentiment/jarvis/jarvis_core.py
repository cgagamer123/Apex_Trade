"""
jarvis_core.py — Jarvis signal interface.

Reads Cerebro reports, runs bots, logs signals and paper trades.
Never does its own data collection — trusts Cerebro completely.

Logs → logs/jarvis.log
"""

from __future__ import annotations

import json
import logging
import sqlite3
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.FileHandler(str(LOG_DIR / "jarvis.log"), encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("jarvis")

REPORTS_DIR  = ROOT / "reports"
REPORT_FILE  = REPORTS_DIR / "cerebro_report.json"
PAUSE_FLAG   = ROOT / "pause.flag"


# ── Helpers ────────────────────────────────────────────────────────────────────

def _is_market_hours() -> bool:
    try:
        import pytz
        from datetime import time as dtime
        et  = pytz.timezone("America/New_York")
        now = datetime.now(et)
        return now.weekday() < 5 and dtime(9, 30) <= now.time() < dtime(16, 0)
    except Exception:
        return True


def load_cerebro_report() -> dict | None:
    try:
        with open(REPORT_FILE) as f:
            return json.load(f)
    except Exception:
        return None


def is_report_stale(report: dict) -> bool:
    try:
        expires = datetime.fromisoformat(report["expires_at"])
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        return datetime.now(timezone.utc) > expires
    except Exception:
        return True


def load_bot_states() -> dict[str, bool]:
    """Read enabled/disabled state for each bot from trade DB."""
    try:
        import config
        with sqlite3.connect(config.TRADE_DB) as c:
            rows = c.execute("SELECT name, enabled FROM bots").fetchall()
        return {r[0]: bool(r[1]) for r in rows}
    except Exception:
        return {"buffett": True, "belfort": True, "standard": True}


# ── Risk + PDT gates ───────────────────────────────────────────────────────────

def check_risk(sig: dict, report: dict) -> dict:
    try:
        from risk_manager import check_trade
        premium    = 1.00   # placeholder — real premium from broker feed
        contracts  = max(1, sig.get("max_risk", 300) // 100)
        return check_trade(premium, contracts)
    except Exception as e:
        return {"approved": True, "reason": f"risk_manager unavailable: {e}"}


def check_pdt(sig: dict) -> dict:
    try:
        from pdt_tracker import is_pdt_blocked, get_pdt_status
        if is_pdt_blocked():
            s = get_pdt_status()
            return {"approved": False,
                    "reason": f"PDT blocked ({s['day_trades_used']}/3), resets {s['resets_on']}"}
        return {"approved": True, "reason": "PDT OK"}
    except Exception as e:
        return {"approved": True, "reason": f"pdt_tracker unavailable: {e}"}


# ── Trade execution (paper) ────────────────────────────────────────────────────

def _log_bot_trade(bot_name: str, sig: dict, report: dict) -> None:
    try:
        import config
        context   = report.get("market_context", {})
        sentiment = report.get("sentiment", {})
        now_s     = datetime.now(timezone.utc).isoformat()[:19]
        with sqlite3.connect(config.TRADE_DB) as c:
            c.execute("""
                CREATE TABLE IF NOT EXISTS bot_trades (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    bot        TEXT,
                    action     TEXT,
                    direction  TEXT,
                    strategy   TEXT,
                    delta      REAL,
                    dte        INTEGER,
                    max_risk   REAL,
                    confidence REAL,
                    reason     TEXT,
                    spy_price  REAL,
                    sentiment  REAL,
                    entry_time TEXT,
                    exit_time  TEXT,
                    pnl        REAL,
                    status     TEXT DEFAULT 'OPEN'
                )
            """)
            c.execute("""
                INSERT INTO bot_trades
                    (bot, action, direction, strategy, delta, dte,
                     max_risk, confidence, reason, spy_price, sentiment, entry_time)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                bot_name,
                sig.get("action"),
                sig.get("direction"),
                sig.get("strategy"),
                sig.get("delta"),
                sig.get("dte"),
                sig.get("max_risk"),
                sig.get("confidence"),
                sig.get("reason", "")[:500],
                context.get("spy_price", 0.0),
                sentiment.get("composite_score", 0.0),
                now_s,
            ))
    except Exception as e:
        log.warning("Failed to log bot trade: %s", e)


def execute_paper_trade(bot_name: str, sig: dict, report: dict) -> dict:
    _log_bot_trade(bot_name, sig, report)
    context = report.get("market_context", {})
    spy     = context.get("spy_price", 0.0)
    log.info("[%s] PAPER TRADE → %s %s %s DTE=%d risk=$%d conf=%.0f%% SPY=%.2f",
             bot_name.upper(),
             sig.get("action"),
             sig.get("direction"),
             sig.get("strategy"),
             sig.get("dte", 0),
             sig.get("max_risk", 0),
             sig.get("confidence", 0) * 100,
             spy)
    return sig


def log_skip(bot_name: str, sig: dict) -> None:
    log.debug("[%s] SKIP — %s", bot_name.upper(), sig.get("reason", ""))


def log_blocked(bot_name: str, check: dict) -> None:
    log.info("[%s] BLOCKED — %s", bot_name.upper(), check.get("reason", ""))


# ── JarvisCore ─────────────────────────────────────────────────────────────────

class JarvisCore:
    def __init__(self) -> None:
        from jarvis.bots.buffett_bot  import BuffettBot
        from jarvis.bots.belfort_bot  import BelfortBot
        from jarvis.bots.standard_bot import StandardBot

        self.bots: dict = {
            "buffett":  BuffettBot(),
            "belfort":  BelfortBot(),
            "standard": StandardBot(),
        }
        self.enabled_bots = load_bot_states()

    def handle_signal(self, bot_name: str, sig: dict, report: dict) -> None:
        if sig["action"] == "SKIP":
            log_skip(bot_name, sig)
            return

        risk_check = check_risk(sig, report)
        if not risk_check["approved"]:
            log_blocked(bot_name, risk_check)
            return

        pdt_check = check_pdt(sig)
        if not pdt_check["approved"]:
            log_blocked(bot_name, pdt_check)
            return

        execute_paper_trade(bot_name, sig, report)

    def refresh_bot_states(self) -> None:
        self.enabled_bots = load_bot_states()

    def run(self) -> None:
        log.info("Jarvis online — waiting for Cerebro reports...")
        last_state_refresh = 0.0

        while True:
            # Respect pause flag
            if PAUSE_FLAG.exists():
                log.debug("Jarvis paused (pause.flag present)")
                time.sleep(15)
                continue

            # Refresh bot enabled/disabled states every 60s
            if time.time() - last_state_refresh > 60:
                self.refresh_bot_states()
                last_state_refresh = time.time()

            report = load_cerebro_report()
            if not report:
                log.debug("No Cerebro report found — waiting...")
                time.sleep(30)
                continue

            if is_report_stale(report):
                ts = report.get("timestamp", "unknown")
                log.debug("Report stale (%s) — waiting for Cerebro refresh", ts)
                time.sleep(15)
                continue

            if not _is_market_hours():
                time.sleep(60)
                continue

            for bot_name, bot in self.bots.items():
                if not self.enabled_bots.get(bot_name, True):
                    continue
                try:
                    sig = bot.generate_signal(report)
                    self.handle_signal(bot_name, sig, report)
                except Exception as e:
                    log.error("[%s] Error: %s", bot_name.upper(), e)

            time.sleep(60)


def main() -> None:
    jarvis = JarvisCore()
    jarvis.run()


if __name__ == "__main__":
    main()
