"""
buffett_bot.py — Conservative, value-oriented bot.

Rules:
  - Only trades ABOVE 200 EMA
  - VIX must be calm (< 25)
  - Sits out FOMC week and high-impact event day
  - Very high sentiment + ML bar (0.80 / 0.70)
  - Debit spreads only, 30 DTE, max $150 risk
"""

from __future__ import annotations


def _skip(reason: str) -> dict:
    return {"action": "SKIP", "reason": reason, "bot": "buffett"}


def _signal(direction: str, strategy: str, delta: float, dte: int,
            max_risk: int, confidence: float, reason: str) -> dict:
    return {
        "action":     "TRADE",
        "bot":        "buffett",
        "direction":  direction,
        "strategy":   strategy,
        "delta":      delta,
        "dte":        dte,
        "max_risk":   max_risk,
        "confidence": round(confidence, 3),
        "reason":     reason,
    }


class BuffettBot:
    NAME = "buffett"

    def generate_signal(self, report: dict) -> dict:
        sentiment = report["sentiment"]["composite_score"]
        ml_prob   = report["ml_prediction"]["probability_bullish"]
        context   = report["market_context"]
        technical = report["technicals"]
        calendar  = report["economic_calendar"]
        hist      = report["historical_context"]

        # ── Hard rules ────────────────────────────────────────────────────
        if not context["above_200ema"]:
            return _skip("below 200 EMA — Buffett never trades here")

        if context["vix"] > 25:
            return _skip(f"VIX {context['vix']:.1f} > 25 — Buffett waits for calm")

        fomc_days = calendar.get("fomc_days_away")
        if fomc_days is not None and fomc_days <= 2:
            return _skip(f"FOMC in {fomc_days} day(s) — Buffett sits out")

        if (calendar.get("impact") in ("HIGH", "CRITICAL")
                and calendar.get("days_away") is not None
                and calendar["days_away"] <= 1):
            ev = calendar.get("next_event", "high-impact event")
            return _skip(f"{ev} {'today' if calendar['days_away']==0 else 'tomorrow'} — Buffett waits")

        # ── Threshold check ────────────────────────────────────────────────
        if abs(sentiment) < 0.80:
            return _skip(f"composite {sentiment:+.2f} below Buffett threshold ±0.80")

        if ml_prob < 0.70 and (1 - ml_prob) < 0.70:
            return _skip(f"ML confidence {max(ml_prob, 1-ml_prob):.0%} < 70% — Buffett needs conviction")

        # ── Technical confirmation ─────────────────────────────────────────
        if not technical["above_ema50"]:
            return _skip("below 50 EMA — Buffett needs full trend alignment")

        # Determine direction from sentiment
        if sentiment > 0:
            direction = "CALL"
            ml_dir    = ml_prob
        else:
            direction = "PUT"
            ml_dir    = 1 - ml_prob

        return _signal(
            direction = direction,
            strategy  = "debit_spread",
            delta     = 0.25,
            dte       = 30,
            max_risk  = 150,
            confidence = ml_dir,
            reason    = (
                f"All Buffett filters passed. "
                f"Sentiment {sentiment:+.2f}. "
                f"ML {ml_dir:.0%}. "
                f"Historical: {hist['bullish_pct']}% bullish. "
                f"EMA 200/50 above."
            ),
        )
