"""
standard_bot.py — Balanced, rules-based bot.

Rules:
  - Sentiment ≥ 0.60
  - Requires MACD confirmation (bullish/bullish_cross)
  - Respects VWAP (must be above)
  - Adjusts size near events via suggested_size_multiplier
  - 14 DTE, single leg, max $300 × size_mult
"""

from __future__ import annotations


def _skip(reason: str) -> dict:
    return {"action": "SKIP", "reason": reason, "bot": "standard"}


def _signal(direction: str, strategy: str, delta: float, dte: int,
            max_risk: int, confidence: float, reason: str) -> dict:
    return {
        "action":     "TRADE",
        "bot":        "standard",
        "direction":  direction,
        "strategy":   strategy,
        "delta":      delta,
        "dte":        dte,
        "max_risk":   max_risk,
        "confidence": round(confidence, 3),
        "reason":     reason,
    }


class StandardBot:
    NAME = "standard"

    def generate_signal(self, report: dict) -> dict:
        sentiment = report["sentiment"]["composite_score"]
        technical = report["technicals"]
        ml_prob   = report["ml_prediction"]["probability_bullish"]
        risk      = report["risk_assessment"]

        # ── Threshold ─────────────────────────────────────────────────────
        if abs(sentiment) < 0.60:
            return _skip(f"score {sentiment:+.2f} below Standard threshold ±0.60")

        # ── MACD confirmation ─────────────────────────────────────────────
        direction = "CALL" if sentiment > 0 else "PUT"
        macd      = technical.get("macd_signal", "")
        if direction == "CALL" and macd not in ("bullish_cross", "bullish"):
            return _skip(f"MACD '{macd}' not confirmed bullish — Standard waits")
        if direction == "PUT" and macd not in ("bearish_cross", "bearish"):
            return _skip(f"MACD '{macd}' not confirmed bearish — Standard waits")

        # ── VWAP ──────────────────────────────────────────────────────────
        if direction == "CALL" and not technical.get("above_vwap"):
            return _skip("below VWAP — Standard waits for reclaim")
        if direction == "PUT" and technical.get("above_vwap"):
            return _skip("above VWAP — Standard waits for rejection")

        # ── Size adjustment ────────────────────────────────────────────────
        size_mult    = risk.get("suggested_size_multiplier", 1.0)
        adjusted_risk = int(300 * size_mult)
        conf          = ml_prob if direction == "CALL" else (1 - ml_prob)

        return _signal(
            direction  = direction,
            strategy   = "single_leg",
            delta      = 0.35,
            dte        = 14,
            max_risk   = adjusted_risk,
            confidence = conf,
            reason     = (
                f"MACD {macd}. "
                f"VWAP {'above' if technical.get('above_vwap') else 'below'}. "
                f"ML {conf:.0%}. "
                f"Risk adjusted to ${adjusted_risk} (×{size_mult:.2f})."
            ),
        )
