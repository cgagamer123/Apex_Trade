"""
belfort_bot.py — Aggressive momentum bot.

Rules:
  - Lower bar: sentiment ≥ 0.55
  - LOVES breakouts (+10% confidence boost)
  - LOVES unusual flow (+5% boost)
  - Short DTE (5 days), single leg, max $300
  - "Let's go"
"""

from __future__ import annotations


def _skip(reason: str) -> dict:
    return {"action": "SKIP", "reason": reason, "bot": "belfort"}


def _signal(direction: str, strategy: str, delta: float, dte: int,
            max_risk: int, confidence: float, reason: str) -> dict:
    return {
        "action":     "TRADE",
        "bot":        "belfort",
        "direction":  direction,
        "strategy":   strategy,
        "delta":      delta,
        "dte":        dte,
        "max_risk":   max_risk,
        "confidence": round(confidence, 3),
        "reason":     reason,
    }


class BelfortBot:
    NAME = "belfort"

    def generate_signal(self, report: dict) -> dict:
        sentiment = report["sentiment"]["composite_score"]
        technical = report["technicals"]
        ml_prob   = report["ml_prediction"]["probability_bullish"]
        options   = report["options"]

        # ── Minimum bar ────────────────────────────────────────────────────
        if abs(sentiment) < 0.55:
            return _skip(f"score {sentiment:+.2f} below Belfort minimum ±0.55")

        # ── Confidence boosts ──────────────────────────────────────────────
        boost = 0.0
        notes = []
        if technical["breakout"]:
            boost += 0.10
            notes.append(f"breakout {technical['breakout_dir']}")
        if options.get("unusual_flow"):
            boost += 0.05
            notes.append(f"flow: {options['unusual_flow']}")

        direction  = "CALL" if sentiment > 0 else "PUT"
        base_conf  = ml_prob if direction == "CALL" else (1 - ml_prob)
        final_conf = min(1.0, base_conf + boost)

        if final_conf < 0.55:
            return _skip(f"ML {final_conf:.0%} too low even for Belfort after boosts")

        return _signal(
            direction  = direction,
            strategy   = "single_leg",
            delta      = 0.45,
            dte        = 5,
            max_risk   = 300,
            confidence = final_conf,
            reason     = (
                f"Belfort triggered. Sentiment {sentiment:+.2f}. "
                f"ML {final_conf:.0%}"
                + (f". Boosts: {', '.join(notes)}" if notes else "")
                + ". Let's go."
            ),
        )
