@echo off
"C:\Users\funny\AppData\Local\Programs\Python\Python312\python.exe" "C:\spy-sentiment\main.py" > C:\spy-sentiment\output.txt 2>&1
