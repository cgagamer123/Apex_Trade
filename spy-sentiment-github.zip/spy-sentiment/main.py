"""
main.py — SPY Options Sentiment Trading System
Runs the pipeline every 15 minutes, checks PDT limits and risk rules,
and prints a structured console signal on every cycle.
"""

from __future__ import annotations

import logging
import sys
import os
from datetime import datetime, timezone

# Force UTF-8 on Windows consoles (skip when stdout is None, e.g. windowed exe)
try:
    if sys.stdout is not None and hasattr(sys.stdout, 'encoding') \
            and sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
        sys.stdout = open(sys.stdout.fileno(), mode="w", encoding="utf-8", buffering=1)
        sys.stderr = open(sys.stderr.fileno(), mode="w", encoding="utf-8", buffering=1)
    elif sys.stdout is None:
        # Windowed frozen exe — redirect to log file
        import os as _os
        _log_dir = _os.path.join(r"C:\spy-sentiment", "logs")
        _os.makedirs(_log_dir, exist_ok=True)
        _log_file = open(_os.path.join(_log_dir, "trading.log"), "a", encoding="utf-8")
        sys.stdout = _log_file
        sys.stderr = _log_file
except Exception:
    pass

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    stream=sys.stdout,
)
log = logging.getLogger("main")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
from scraper.pipeline import run_pipeline
from storage.db       import init_db, get_signal_history
from pdt_tracker      import get_pdt_status, is_pdt_blocked
from risk_manager     import risk_summary, check_trade, suggest_contracts, calculate_stops
from trade_logger     import log_signal, get_open_position_cost, get_total_pnl

# ── ANSI colours (safe on most modern terminals) ──────────────────────────────
RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RESET  = "\033[0m"

_SIGNAL_COLOR = {"BULLISH": GREEN, "BEARISH": RED, "NEUTRAL": YELLOW}

W = 44   # column width of the dashboard box


# ── header banner ─────────────────────────────────────────────────────────────

def _print_header(pdt: dict, risk: dict) -> None:
    used_pct = risk["open_position_cost"] / risk["account_size"] * 100
    free     = risk["account_size"] - risk["open_position_cost"]

    pdt_warn  = pdt["day_trades_used"] >= config.PDT_WARN_AT
    risk_warn = risk["open_position_cost"] >= config.RISK_WARN_AT

    pdt_color  = RED if pdt_warn  else GREEN
    risk_color = RED if risk_warn else GREEN

    print()
    print("=" * W)
    print("  SPY SENTIMENT TRADING SYSTEM")
    print(f"  Account: ${risk['account_size']:,.0f} | "
          f"Used: {risk_color}${risk['open_position_cost']:,.0f}{RESET} | "
          f"Free: ${free:,.0f}")
    print(f"  PDT Day Trades: "
          f"{pdt_color}{pdt['day_trades_used']}/{config.PDT_MAX_DAY_TRADES}{RESET}"
          f"  (resets {pdt['resets_on']})")
    print("=" * W)


# ── signal block ──────────────────────────────────────────────────────────────

def _print_signal(result: dict, pdt: dict, risk: dict) -> None:
    sig   = result["signal"]
    score = result["composite_score"]
    color = _SIGNAL_COLOR.get(sig, "")

    # Determine a representative example trade for display
    # (use suggest_contracts with a typical $2.50 ATM premium as placeholder)
    EXAMPLE_PREMIUM = 2.50
    n_contracts = suggest_contracts(EXAMPLE_PREMIUM)
    n_contracts = max(n_contracts, 1)   # show at least 1 for display
    risk_check  = check_trade(EXAMPLE_PREMIUM, n_contracts)
    stops       = calculate_stops(EXAMPLE_PREMIUM)

    action = "BUY CALL" if sig == "BULLISH" else ("BUY PUT" if sig == "BEARISH" else "HOLD / NO TRADE")

    print(f"  Signal: {color}{sig} ({score:+.2f}){RESET} | Action: {action}")

    if sig != "NEUTRAL":
        rc_color = GREEN if risk_check["approved"] else RED
        print(f"  Risk Check: {rc_color}{risk_check['reason']}{RESET}")
        if risk_check["approved"]:
            print(f"  Stop Loss: ${stops['stop_loss']:.2f} | "
                  f"Profit Target: ${stops['profit_target']:.2f}")
        if pdt["blocked"]:
            print(f"  {RED}*** PDT LIMIT REACHED - DAY TRADES BLOCKED ***{RESET}")
        elif pdt["day_trades_used"] >= config.PDT_WARN_AT:
            print(f"  {RED}WARNING: {pdt['day_trades_used']} day trades used - "
                  f"only {pdt['day_trades_remaining']} remaining{RESET}")
        if risk["open_position_cost"] >= config.RISK_WARN_AT:
            print(f"  {RED}WARNING: ${risk['open_position_cost']:.0f} at risk - "
                  f"approaching position limit{RESET}")
    print("=" * W)


# ── history + top headlines ───────────────────────────────────────────────────

def _print_detail(result: dict) -> None:
    print(f"  Articles: {result['article_count']}  |  "
          f"Weight: {result['total_weight']:.2f}  |  "
          f"Score: {result['composite_score']:+.4f}")
    print()

    if result.get("top_articles"):
        print("  Top headlines:")
        for i, a in enumerate(result["top_articles"], 1):
            age = ""
            try:
                pub = datetime.fromisoformat(a["published_at"])
                hrs = (datetime.now(timezone.utc) - pub).total_seconds() / 3600
                age = f" ({hrs:.1f}h ago)"
            except Exception:
                pass
            s   = a["sentiment_score"]
            bar = "^" if s > 0 else ("v" if s < 0 else "-")
            print(f"  {i}. [{bar}{s:+.2f} w={a['decay_weight']:.2f}] "
                  f"{a['title'][:60]}{age}")
        print()

    history = get_signal_history(limit=5)
    if len(history) > 1:
        print("  Recent signals:")
        for h in history:
            c = _SIGNAL_COLOR.get(h["signal"], "")
            print(f"    {h['run_at'][:19]}  {c}{h['signal']:8s}{RESET}"
                  f"  {h['composite_score']:+.4f}")
        print()

    pnl = get_total_pnl()
    print(f"  Realised PnL: ${pnl:+,.2f}")
    print("=" * W)
    print()


# ── main job ──────────────────────────────────────────────────────────────────

def job() -> None:
    log.info("Pipeline starting...")
    try:
        result = run_pipeline(persist=True)
    except Exception as exc:
        log.error("Pipeline failed: %s", exc, exc_info=True)
        return

    pdt  = get_pdt_status()
    risk = risk_summary()

    # Log signal to trade_logger
    try:
        sources = [a["source"] for a in result.get("top_articles", [])]
        log_signal(
            timestamp        = datetime.fromisoformat(result["run_at"]),
            sentiment_score  = result["composite_score"],
            signal_direction = result["signal"],
            sentiment_sources= sources,
        )
    except Exception as exc:
        log.warning("Signal log failed: %s", exc)

    _print_header(pdt, risk)
    _print_signal(result, pdt, risk)
    _print_detail(result)


# ── entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    init_db()
    job()

    try:
        import schedule  # type: ignore
        import time
        from pathlib import Path
        PAUSE_FLAG = Path(__file__).parent / "pause.flag"

        schedule.every(config.PIPELINE_INTERVAL_MINUTES).minutes.do(job)
        log.info("Scheduler running - next cycle in %d min. Ctrl+C to stop.",
                 config.PIPELINE_INTERVAL_MINUTES)
        while True:
            if PAUSE_FLAG.exists():
                log.info("Bots paused (pause.flag detected). Waiting...")
                time.sleep(5)
                continue
            schedule.run_pending()
            time.sleep(30)
    except ImportError:
        log.warning("`schedule` not installed - single run only.")
    except KeyboardInterrupt:
        log.info("Stopped by user.")


if __name__ == "__main__":
    main()
