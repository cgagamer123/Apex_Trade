# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['launcher\\launch.py'],
    pathex=[],
    binaries=[],
    datas=[('dashboard', 'dashboard'), ('assets', 'assets'), ('launcher', 'launcher'), ('scraper', 'scraper'), ('storage', 'storage'), ('cerebro', 'cerebro'), ('jarvis', 'jarvis')],
    hiddenimports=['pystray', 'PIL', 'flask', 'werkzeug', 'win32com.client', 'schedule', 'feedparser', 'pandas', 'numpy', 'transformers', 'torch', 'yfinance', 'pytz', 'scraper.pipeline', 'scraper.fetchers', 'scraper.processor', 'storage.db', 'dashboard.app', 'cerebro.cerebro_engine', 'cerebro.report_compiler', 'cerebro.historical.era_classifier', 'cerebro.historical.pattern_library', 'cerebro.historical.economic_calendar', 'cerebro.historical.cerebro_trainer_v2', 'jarvis.jarvis_core', 'jarvis.bots.buffett_bot', 'jarvis.bots.belfort_bot', 'jarvis.bots.standard_bot', 'sqlite3'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='Cerebro Trading',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['assets\\icon.ico'],
)
